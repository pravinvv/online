export const environment = {
	production: true,
	SVC_AUTH_URL: 'http://localhost/1.0.0',
	SVC_ADMIN: 'http://localhost/1.0.0',
	api: {
		login: '/login',
		users: '/register',
		logout: '/logout',
		createOrganisation: '/organisation',
		updateOrganisation: '/organisation/{id}', // run time appending orgId
		listOrganisation: '/organisation',
		deleteOrganisation: '/organisation/{id}',
		getSingleOrganisation: '/organisation/{id}', //// run time appending orgId

		createWorkspace: '/workspace',
		updateWorkspace: '/workspace/{id}',
		listWorkspace: '/workspace',
		getSingleWorkspace: '/workspace/{id}',
		deleteWorkspace: '/workspace/{id}',

		createIntent: '/workspace/{workspace_id}/intent',
		updateIntent: '/workspace/{workspace_id}/intent/{intent_id}',
		listIntent: '/workspace/{workspace_id}/intent',
		getSingleIntent: '/workspace/{workspace_id}/intent/{intent_id}',
		deleteIntent: '/workspace/{workspace_id}/intent/{intent_id}',

		createExample: '/workspace/{workspace_id}/intent/{intent_id}/user_example',
		updateExample: '/workspace/{workspace_id}/intent/{intent_id}/user_example/{example_id}',
		getExampleList: '/workspace/{workspace_id}/intent/{intent_id}/user_example',
		getSingleExample: '/workspace/{workspace_id}/intent/{intent_id}/user_example/{example_id}',
		deleteExample: '/workspace/{workspace_id}/intent/{intent_id}/user_example/{example_id}',


		createDialogNode: '/workspace/{workspace_id}/dialog_node',
		updateDialogNode: '/workspace/{workspace_id}/dialog_node/{dialog_node_id}',
		listDialogNode: '/workspace/{workspace_id}/dialog_node',
		getSingleDialogNode: '/workspace/{workspace_id}/dialog_node/{dialog_node_id}',
		deleteDialogNode: '/workspace/{workspace_id}/dialog_node/{dialog_node_id}',
	},
};
