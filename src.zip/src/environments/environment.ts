// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
	production: false,

	SVC_ADMIN: 'http://192.168.1.81:8001/1.0.0',
	SVC_AUTH_URL: 'http://192.168.1.81:8000/1.0.0',
	SVC_MESSAGE: 'https://192.168.1.81:8003/1.0.0',
	SVC_APP: 'https://192.168.1.81:8002/1.0.0',
	api: {
		login: '/login',
		users: '/register',
		logout: '/logout',
		refreshToken: '/refresh_token',

		me: '/me',

		createOrganisation: '/organisation',
		updateOrganisation: '/organisation/{id}', // run time appending orgId
		listOrganisation: '/organisation',
		deleteOrganisation: '/organisation/{id}',
		getSingleOrganisation: '/organisation/{id}', //// run time appending orgId

		createWorkspace: '/workspace',
		updateWorkspace: '/workspace/{id}',
		listWorkspace: '/workspace',
		getSingleWorkspace: '/workspace/{id}',
		deleteWorkspace: '/workspace/{id}',

		createIntent: '/workspace/{workspace_id}/intent',
		updateIntent: '/workspace/{workspace_id}/intent/{intent_id}',
		listIntent: '/workspace/{workspace_id}/intent',
		getSingleIntent: '/workspace/{workspace_id}/intent/{intent_id}',
		deleteIntent: '/workspace/{workspace_id}/intent/{intent_id}',

		createExample: '/workspace/{workspace_id}/intent/{intent_id}/user_example',
		updateExample: '/workspace/{workspace_id}/intent/{intent_id}/user_example/{example_id}',
		getExampleList: '/workspace/{workspace_id}/intent/{intent_id}/user_example',
		getSingleExample: '/workspace/{workspace_id}/intent/{intent_id}/user_example/{example_id}',
		deleteExample: '/workspace/{workspace_id}/intent/{intent_id}/user_example/{example_id}',

		createDialogNode: '/workspace/{workspace_id}/dialog_node',
		updateDialogNode: '/workspace/{workspace_id}/dialog_node/{dialog_node_id}',
		listDialogNode: '/workspace/{workspace_id}/dialog_node',
		getSingleDialogNode: '/workspace/{workspace_id}/dialog_node/{dialog_node_id}',
		deleteDialogNode: '/workspace/{workspace_id}/dialog_node/{dialog_node_id}',

		createProduct: '/product',
		updateProduct: '/product/{id}', // run time appending product id
		listProduct: '/product',
		deleteProduct: '/product/{id}',
		getSingleProduct: '/product/{id}', //// run time appending product id
		uploadProductImage: '/upload_image',

		getTwillioToken: '/twilio_token',
		getChannels: '/channel',
		autopilotONOFF: '/conversation/{id}',

		userlist: '/user',
		createuser: '/user',
		getSingleUser: '/user/{id}',
		updateUser: '/user/{id}',
		deleteUser: '/user/{id}',

		staffList: '/staff',
		createStaff: '/staff',
		getSingleStaff: '/staff/{id}',
		updateStaff: '/staff/{id}',
		deleteStaff: '/staff/{id}',
	},
};

/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.