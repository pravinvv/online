import { HasPermissionDirective } from './has-permission.directive';
import { TemplateRef, ViewContainerRef } from '@angular/core';
import { NgIfContext } from '@angular/common';
import { AuthService } from '../../core/services/auth.service';

describe('HasPermissionDirective', () => {
  let templateRef:TemplateRef<NgIfContext>;
  let viewContainer: ViewContainerRef;
  let auth:AuthService;  
  it('should create an instance of custom has permission directive', () => {
    const directive = new HasPermissionDirective(templateRef,viewContainer,auth);
    expect(directive).toBeTruthy();
  });
});
