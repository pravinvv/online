import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { NgIfContext } from '@angular/common';
import { AuthService } from 'src/app/core/services/auth.service';

@Directive({
	selector: '[appHasPermission]',
})
export class HasPermissionDirective {
	constructor(
		private templateRef: TemplateRef<NgIfContext>,
		private viewContainer: ViewContainerRef,
		private authService: AuthService
	) {}
	@Input('appHasPermission') set appHasPermission(condition: string) {
		const { type, email } = this.authService.sessionUserInfo;
		if (type === condition || condition === 'all') {
			this.viewContainer.createEmbeddedView(this.templateRef);
		} else {
			this.viewContainer.clear();
		}
	}
}
