import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SpinnerComponent } from './components/spinner/spinner.component';
import { ConfirmModelComponent } from './components/confirm-model/confirm-model.component';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { ListComponent } from './components/list/list.component';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { HasPermissionDirective } from './directives/has-permission.directive';

@NgModule({
	declarations: [SpinnerComponent, ConfirmModelComponent, ListComponent, HasPermissionDirective],
	imports: [CommonModule, NgxUiLoaderModule, Ng2SmartTableModule],
	exports: [SpinnerComponent, ListComponent,HasPermissionDirective],
	entryComponents: [ConfirmModelComponent],
})
export class SharedModule {}
