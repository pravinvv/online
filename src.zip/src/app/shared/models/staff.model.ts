import { OrganisationModel } from './organisation.model';
import { UserInfoModel } from './user.model';

export interface StaffModel {
	id: number;
	organisation_id: string;
	user_id: string;
	status: string;
	type: string;
	request_handling: number;
	Organisation?: OrganisationModel;
	User?: UserInfoModel;
}
