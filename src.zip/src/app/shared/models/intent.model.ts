import { UserExample } from './user_example.model';

export interface IntentModel {
	intent: string;
	description: string;
	metadata?: string;
	examples?: UserExample[];
}
