export interface RegisterModel {
	first_name: string;
	last_name: string;
	email: string;
	password: string;
	confirm_password: string;
	tnc: boolean;
}

export interface LoginModel {
	username: string;
	password: string;
	remember_me: boolean;
}

export interface UserModel {
	name: string;
	email: string;
	mobile_number: string;
}

export interface UserInfoModel {
	id: number;
	first_name: string;
	last_name: string;
	email: string;
	status: string;
	phone_number: string;
	password: string;
	type: string;
	name?: string;
}
