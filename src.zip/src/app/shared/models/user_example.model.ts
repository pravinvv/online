export interface UserExample {
	intent: string;
	text: string;
	mentions?: MentionModel;
}
interface MentionModel {
	entity?: string;
	location?: Number[];
}
