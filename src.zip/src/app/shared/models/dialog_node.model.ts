export interface DialogNodeModel {
	dialog_node: string;
	title: string;
	description: string;
	conditions?: string;
	parent?: string;
	previous_sibling?: string;
	context?: {};
	metadata?: {};
	output?: OutputModel;
}
interface OutputModel {
	generic?: GenericModel[];
}
interface GenericModel {
	response_type: string;
	selection_policy: string;
	values: ValuesModel[];
}
interface ValuesModel {
	text: string;
}
