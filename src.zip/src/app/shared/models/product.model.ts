export interface ProductModel {
	id: number;
	name: string;
	description: string;
	image_url: string;
	organisation_id: number;
	created_at?: Date;
	updated_at?: Date;
	nego_params: Array<NegoParamsModel>;
}
interface NegoParamsModel {
	name: string;
	min: number;
	baseline: number;
	weight: number;
	inverse: boolean;
}
