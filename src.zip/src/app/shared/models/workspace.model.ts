import { DialogNodeModel } from './dialog_node.model';
import { IntentModel } from './intent.model';

export interface WorkspaceModel {
	name: string;
	description: string;
	language?: string;
	metadata?: {};
	learning_opt_out?: boolean;
	workspace_id?: string;
	intents?: IntentModel[];
	dialog_nodes?: DialogNodeModel[];
}
