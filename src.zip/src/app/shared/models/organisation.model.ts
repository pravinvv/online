import {UserModel} from './user.model';

export interface OrganisationModel {
	name: string;
	id: number;
	workspace_id: string;
	owner?: UserModel;
	status: string;
}
