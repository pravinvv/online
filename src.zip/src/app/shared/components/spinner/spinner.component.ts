import { Component, Input, OnDestroy, ViewEncapsulation, OnInit } from '@angular/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { LoaderService } from '../../services/loader.service';

@Component({
	selector: 'app-spinner',
	template: `
		<div>
			<ng-content ngxUiLoaderBlurred></ng-content>
			<div class="spinner">
				<div class="double-bounce1"></div>
				<div class="double-bounce2"></div>
			</div>
			<ngx-ui-loader
				*ngIf="loaderId != 'master'"
				[loaderId]="loaderId"
				[fgsType]="'ball-spin-clockwise'"
				[hasProgressBar]="'false'"
			></ngx-ui-loader>
			<ngx-ui-loader *ngIf="loaderId === 'master'"></ngx-ui-loader>
		</div>
	`,
	encapsulation: ViewEncapsulation.None,
})
export class SpinnerComponent implements OnDestroy, OnInit {
	public isSpinnerVisible = true;

	@Input() public loaderId = 'loader-01';

	constructor(private ngxLoader: NgxUiLoaderService, private loaderService: LoaderService) {}
	ngOnInit() {
		this.loaderService.getLoaderInfo().subscribe(info => {
			if (info.start) {
				this.isSpinnerVisible = true;
				this.ngxLoader.stopAll();
				this.ngxLoader.startLoader(info.loaderId);
			} else {
				this.isSpinnerVisible = false;
				this.ngxLoader.stopLoaderAll(info.loaderId);
			}
		});
	}
	ngOnDestroy(): void {
		this.isSpinnerVisible = false;
	}
}
