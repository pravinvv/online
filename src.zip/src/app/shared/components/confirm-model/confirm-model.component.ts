import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
	selector: 'app-confirm-model',
	templateUrl: './confirm-model.component.html',
	styleUrls: ['./confirm-model.component.css'],
})
export class ConfirmModelComponent implements OnInit {
	@Input() data: any;
	constructor(public modal: NgbActiveModal) {}

	ngOnInit() {}
}
