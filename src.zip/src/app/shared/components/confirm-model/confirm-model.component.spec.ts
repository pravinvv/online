import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmModelComponent } from './confirm-model.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgbTabsetModule, NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgModule } from '@angular/core';

describe('ConfirmModelComponent', () => {
  let component: ConfirmModelComponent;
  let fixture: ComponentFixture<ConfirmModelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmModelComponent ],
      imports:[HttpClientTestingModule,NgbTabsetModule],
      providers:[{ provide: NgbActiveModal, useValue:NgbActiveModal }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
