import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';

@Component({
	selector: 'app-list',
	templateUrl: './list.component.html',
	styleUrls: ['./list.component.css'],
})
export class ListComponent implements OnInit {
	@Input('settings')
	private set tableSetting(config) {
		this.settings = config;
	}

	@Input('list') private set dataList(data) {
		this.source = new LocalDataSource(data); // create the source
	}
	// tslint:disable-next-line:no-inferrable-types
	@Input() private uniqueKey: string = 'id';
	@Output() delete: EventEmitter<number> = new EventEmitter<number>();
	@Output() edit: EventEmitter<number> = new EventEmitter<number>();
	@Output() add: EventEmitter<number> = new EventEmitter<number>();

	public source: LocalDataSource;
	public settings: any;

	constructor() {}

	ngOnInit() {}
	onCustom(event) {
		// alert(`Custom event '${event.action}' fired on row №: ${event.data.id}`);
		switch (event.action) {
			case 'Edit':
				this.edit.emit(event.data[this.uniqueKey]);
				break;
			case 'Delete':
				this.delete.emit(event.data.data[this.uniqueKey]);
				break;
			default:
		}
	}
	addNew() {
		this.add.emit();
	}
}
