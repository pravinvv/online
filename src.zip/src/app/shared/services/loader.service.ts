import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
	providedIn: 'root',
})
export class LoaderService {
	private startLoader$: Subject<any> = new Subject<any>();
	constructor() {}
	public startLoader(id: string) {
		this.startLoader$.next({ loaderId: id, start: true });
	}
	public stopLoader(id: string) {
		this.startLoader$.next({ loaderId: id, start: false });
	}
	public getLoaderInfo() {
		return this.startLoader$.asObservable();
	}
}
