import { Injectable } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmModelComponent } from '../components/confirm-model/confirm-model.component';
@Injectable({
	providedIn: 'root',
})
export class ModalService {
	private MODALS = {
		confirmation: ConfirmModelComponent,
	};
	constructor(private _modalService: NgbModal) {}

	open(data) {
		const { name } = data;
		const modalRef = this._modalService.open(this.MODALS[name]);
		modalRef.componentInstance.data = data;
		return modalRef;
	}
}
