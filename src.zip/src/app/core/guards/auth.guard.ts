import { Injectable } from '@angular/core';
import {
	ActivatedRouteSnapshot,
	RouterStateSnapshot,
	CanActivateChild,
	Router,
	CanActivate,
	CanDeactivate,
} from '@angular/router';
import { AuthService } from '../services/auth.service';

interface CanDeactivateComponent {
	CanDeactivate(): boolean;
}
@Injectable({
	providedIn: 'root',
})
export class AuthGuard implements CanActivate, CanActivateChild, CanDeactivate<CanDeactivateComponent> {
	constructor(private auth: AuthService, private router: Router) { }
	canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
		const currentUrl = location.pathname;
		const url = state.url;
		if (
			(currentUrl.search('secured') < 0 && this.auth.isAuthenticated) ||
			(url.search('secured') < 0 && this.auth.isAuthenticated)
		) {
			this.router.navigate(['/secured/dashboard']);
			return false;
		}
		return true;
	}
	canActivateChild(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
		const currentUrl = location.pathname;
		const url = state.url;
		if (
			(currentUrl.search('secured') > 0 && this.auth.isAuthenticated) ||
			(url.search('secured') > 0 && this.auth.isAuthenticated)
		) {
			return true;
		}
		this.router.navigate(['/login']);
		return false;
		
	





	}
	canDeactivate(
		component: CanDeactivateComponent,
		next: ActivatedRouteSnapshot,
		state: RouterStateSnapshot
	): boolean {
		const url = location.pathname;
		if (['/login', '/signup', '/404', '/lock'].indexOf(url.toString()) > -1 && this.auth.isAuthenticated) {
			return false;
		}
		return true;
	}
}
