import { TestBed, async, inject } from '@angular/core/testing';
import { AccessGuard } from './access.guard';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

describe('AccessGuard', () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [AccessGuard],
			imports: [HttpClientTestingModule, RouterTestingModule],
		});
	});

  it('should create access guard ...', inject([AccessGuard], (guard: AccessGuard) => {
    expect(guard).toBeTruthy();
  }));




  
});
