import { TestBed, async, inject } from '@angular/core/testing';

import { SuperadminGuard } from './superadmin.guard';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

describe('SuperadminGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SuperadminGuard],
      imports:[HttpClientTestingModule,RouterTestingModule]
    });
  });

  it('should create superadmin guard ...', inject([SuperadminGuard], (guard: SuperadminGuard) => {
    expect(guard).toBeTruthy();
  }));
});
