import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';

@Injectable({
	providedIn: 'root',
})
export class AccessGuard implements CanActivate {
  constructor(private auth: AuthService, private router: Router) { }
  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const { type, Staff: { organisation_id } } = this.auth.sessionUserInfo;
    if (!['superadmin'].includes((type||'').toLowerCase())) {
      let url = state.url.toString().replace('/secured/', '');
      url = `secured/organisation/${organisation_id}/${url}`;
      this.router.navigateByUrl(url)
      return false;
    }
    else {
      return true;
    }
  }



}
