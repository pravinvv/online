import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, Router, CanActivate } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable({
	providedIn: 'root',
})
export class AdminGuard implements CanActivate {
	constructor(private auth: AuthService, private router: Router) {}
	canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
		const {
			type,
			Staff: { organisation_id },
		} = this.auth.sessionUserInfo;
		if (!['admin'].includes(type.toLowerCase())) {
			this.router.navigate(['/secured/dashboard']);
			return false;
		} else {
			return true;
		}
	}
}
