import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';

@Injectable({
	providedIn: 'root',
})
export class AuthService {
	// tslint:disable-next-line:no-inferrable-types
	private authenticated: boolean = false;

	public get isAuthenticated() {
		const token = this.getStorageInfo('token');
		this.authenticated = token ? true : false;
		return this.authenticated;
	}
	public get getToken() {
		const token = this.getStorageInfo('token');
		return token ? token.authToken : null;
	}
	public get sessionUserInfo() {
		let userInfo = this.getStorageInfo('userInfo');
		userInfo = userInfo || {};
		userInfo.Staff = userInfo.Staff || {};
		userInfo.Staff.Organisation = userInfo.Staff.Organisation || {};
		return userInfo;
	}
	public set isAuthenticated(value: boolean) {
		this.authenticated = value;
	}

	constructor(private http: HttpClient, private router: Router) {}

	doLogin(data) {
		return this.http
			.post<any>(`${environment.SVC_AUTH_URL}${environment.api.login}`, {
				email: data.username,
				password: data.password,
			})
			.pipe(
				map(payload => {
					// login successful if there's a jwt token in the response
					if (payload && payload.token) {
						// store user details and jwt token in local storage to keep user logged in between page refreshes
						this.setStorageInfo('token', payload.token);
					}
					return payload;
				})
			);
	}
	doRegister(data) {
		return this.http.post<any>(`${environment.SVC_AUTH_URL}${environment.api.users}`, data).pipe(
			map((payload: any) => {
				return payload;
			})
		);
	}
	doLogout() {
		 this.http.get<any>(`${environment.SVC_AUTH_URL}${environment.api.logout}`).subscribe((payload: any) => {
			sessionStorage.removeItem('token');
			this.router.navigate(['/login']);
		});
	}
	refreshToken() {
		const tokenData = this.getStorageInfo('token');
		const userInfo = this.getStorageInfo('userInfo');

		const data = {
			user_id: userInfo.id,
			refreshToken: tokenData.refreshToken,	
		};
		
		return this.http.post<any>(`${environment.SVC_AUTH_URL}${environment.api.refreshToken}`, data);
	}
	sessionTimeout() {
		this.doLogout();
	}

	private getStorageInfo(key: string): any {
		const values = sessionStorage.getItem(key);
		if (values) {
			return JSON.parse(values);
		}
		return null;
	}
	setStorageInfo(key: string, values: any) {
		return sessionStorage.setItem(key, JSON.stringify(values));
	}
}
