import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { AuthService } from '../services/auth.service';
import { map, mergeMap, toArray, filter } from 'rxjs/operators';
import { RegisterModel, UserInfoModel } from 'src/app/shared/models/user.model';
import { ToastService } from '../../shared/services/toast.service';
import { throwError, Observable, of } from 'rxjs';

@Injectable({
	providedIn: 'root',
})
export class UserService {
	private baseUrl;
	constructor(private http: HttpClient, private authService: AuthService, private toast: ToastService) {
		this.baseUrl = environment.SVC_ADMIN;
	}
	private error(err) {
		err = err || {};
		this.toast.showError(err.message);
		return err.message;
	}
	getUserInfo() {
		return this.http.get<RegisterModel>(`${environment.SVC_AUTH_URL}${environment.api.me}`).pipe(
			map((payload: RegisterModel) => {
				this.authService.setStorageInfo('userInfo', payload);
				return payload;
			})
		);
	}
	getUserList(): Observable<any> {
		const url = `${this.baseUrl}${environment.api.userlist}`;
		return this.http
			.get<any>(url)
			.pipe(
				mergeMap(u => {
					// u.name = `${u.first_name} ${u.last_name}`;
					return u;
				}),
				mergeMap((u: any) => {
					u.name = `${u.first_name} ${u.last_name}`;
					return of(u);
				}),
				filter(user => user.type !== 'customer' && user.status === 'active'),
				toArray()
			)
			.catch(err => throwError(this.error(err)));
	}
	createUser(User: UserInfoModel): Observable<UserInfoModel> {
		const url = `${this.baseUrl}${environment.api.createuser}`;
		return this.http.post<UserInfoModel>(url, User).catch(err => throwError(this.error(err)));
	}
	getSingleUser(userId: number): Observable<UserInfoModel> {
		let url = `${this.baseUrl}${environment.api.getSingleUser}`;
		url = url.replace('{id}', userId.toString());
		return this.http.get<UserInfoModel>(url).catch(err => throwError(this.error(err)));
	}

	updateUser(userId: number, User: UserInfoModel): Observable<UserInfoModel> {
		let url = `${this.baseUrl}${environment.api.updateUser}`;
		url = url.replace('{id}', userId.toString());
		return this.http.put<UserInfoModel>(url, User).catch(err => throwError(this.error(err)));
	}
	deleteUser(userId: number): Observable<HttpResponse<any>> {
		let url = `${this.baseUrl}${environment.api.deleteUser}`;
		url = url.replace('{id}', userId.toString());
		return this.http.delete<HttpResponse<any>>(url).catch(err => throwError(this.error(err)));
	}
}
