import { TestBed, inject } from '@angular/core/testing';
import * as userinfo from '../../../spec/mock/core/services/user-service.json';
import { UserService } from './user.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ToastService } from '../../shared/services/toast.service';
import { environment } from 'src/environments/environment';

describe('UserService', () => {
	beforeEach(() =>
		TestBed.configureTestingModule({
			providers: [UserService, { provide: ToastService, useValue: ToastService }],
			imports: [HttpClientTestingModule, RouterTestingModule],
		})
	);
	beforeEach(() => {
		this.mockuserinfo = userinfo;
	});

	it('should  create user service', () => {
		const service: UserService = TestBed.get(UserService);
		expect(service).toBeTruthy();
	});

	describe(' should call to the login api', () => {
		beforeEach(() =>
			TestBed.configureTestingModule({
				imports: [HttpClientTestingModule],
				providers: [{ provide: ToastService, useValue: ToastService }],
			})
		);
		it('should return the token if the user is logged In', inject(
			[HttpTestingController, UserService, ToastService],
			(httpMock: HttpTestingController, service: UserService) => {
				let baseUrl = environment.SVC_ADMIN;
				// Make an HTTP request
				service.getUserInfo().subscribe(response => {
					// When observable resolves, result should match test data
					expect(response).toEqual(this.mockuserinfo);
				});
				// HTTP request mock
				const mockUrl = `${environment.SVC_AUTH_URL}${environment.api.me}`;
				const req = httpMock.expectOne(mockUrl);
				expect(req.request.method).toEqual('GET');
				req.flush(this.mockuserinfo);
				httpMock.verify();
			}
		)); // UserService
	});
});
