import { TestBed, inject } from '@angular/core/testing';
import { AuthService } from './auth.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import * as authdata from '../../../spec/mock/core/services/auth-data.json';
import * as authservice from '../../../spec/mock/core/services/auth-service.json';
import * as authregister from '../../../spec/mock/core/services/auth-register.json';
import * as refreshtoken from '../../../spec/mock/core/services/refresh-token.json';
import { ToastService } from '../../shared/services/toast.service';
import { environment } from '../../../environments/environment';
describe('AuthService', () => {
	beforeEach(() => TestBed.configureTestingModule({
		imports: [HttpClientTestingModule, RouterTestingModule],
	}));
	beforeEach(() => {
		this.mockacessguard = authservice;
		this.mockauthdata = authdata;
		this.mockregister = authregister;
		this.mockrefreshtoken = refreshtoken;
	});
	sessionStorage.setItem('token', JSON.stringify({
		"authToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTAsImZpcnN0X25hbWUiOiJ0ZXN0K2ZpcnN0bG9naW4iLCJsYXN0X25hbWUiOiJOZXciLCJwaG9uZV9udW1iZXIiOiIyNDIuMjA4LjE1NjEiLCJlbWFpbCI6InRlc3QrZmlyc3Rsb2dpbkBuZWdvYm90LmNvIiwidHlwZSI6ImFkbWluIiwic3RhdHVzIjoiYWN0aXZlIiwicHJvZmlsZV9pbWFnZV91cmwiOiJodHRwOi8vdmlhLnBsYWNlaG9sZGVyLmNvbS81MDB4NTAwIiwidHdpbGlvX3VzZXJfaWQiOm51bGwsImRldmljZV90b2tlbiI6bnVsbCwiYXBwX3N0YXR1cyI6bnVsbCwiZmlyc3Rfc2lnbmluIjp0cnVlLCJpYXQiOjE1NjAyMzM5NTgsImV4cCI6MTU2MDI0MTE1OH0.JdSNhXoyPrZtquWHndJZUmcSOcBSe0AXykLm9rzfYIw",
		"refreshToken": "593a4b75-6d56-4982-8a74-3a4ce9ccbb58"
	}));
	sessionStorage.setItem('userInfo', JSON.stringify({
		"id": 10,
		"first_name": "test+firstlogin",
		"last_name": "New",
		"phone_number": "242.208.1561",
		"email": "test+firstlogin@negobot.co",
		"type": "admin",
		"status": "active",
		"profile_image_url": "http://via.placeholder.com/500x500",
		"twilio_user_id": null,
		"device_token": null,
		"app_status": null,
		"first_signin": true,
		"Staff": {
			"id": 17,
			"organisation_id": 1,
			"user_id": 10,
			"type": "admin",
			"Organisation": {
				"id": 1,
				"name": "Org Name",
				"workspace_id": "1d167ef0-39ef-4fc7-bda0-829d6bcbd5cd",
				"status": "active"
			}
		}
	}));

	it('should be created', () => {
		const service: AuthService = TestBed.get(AuthService);
		expect(service).toBeTruthy();
	});

	describe(' should call to the login api', () => {
		beforeEach(() => TestBed.configureTestingModule({
			imports: [
				HttpClientTestingModule],
			providers: [{ provide: ToastService, useValue: ToastService }]
		}));
		it('should return the token if the user is logged In', inject([HttpTestingController, AuthService, ToastService], (
			httpMock: HttpTestingController,
			service: AuthService, ) => {
			let baseUrl = environment.SVC_ADMIN;
			// Make an HTTP request
			service.doLogin(this.mockauthdata).subscribe(response => {
				// When observable resolves, result should match test data
				expect(response).toEqual(this.mockacessguard);
			});
			// HTTP request mock
			const mockUrl = `${environment.SVC_AUTH_URL}${environment.api.login}`;
			const req = httpMock.expectOne(mockUrl);
			expect(req.request.method).toEqual('POST');
			req.flush(this.mockacessguard);
			httpMock.verify();
		})); // LogInUser
	});

	describe(' should call to register api', () => {
		beforeEach(() => TestBed.configureTestingModule({
			imports: [
				HttpClientTestingModule],
			providers: [{ provide: ToastService, useValue: ToastService }]
		}));
		it('should equal to  json response', inject([HttpTestingController, AuthService, ToastService], (
			httpMock: HttpTestingController,
			service: AuthService, ) => {
			let baseUrl = environment.SVC_ADMIN;
			// Make an HTTP request
			service.doRegister(this.mockregister).subscribe(response => {
				// When observable resolves, result should match test data
				expect(response).toEqual(this.mockregister);
			});
			// HTTP request mock
			const mockUrl = `${environment.SVC_AUTH_URL}${environment.api.users}`;
			const req = httpMock.expectOne(mockUrl);
			expect(req.request.method).toEqual('POST');
			req.flush(this.mockregister);
			httpMock.verify();
		}));// RegisterUser

	});

	describe(' should call to refresh token api', () => {
		beforeEach(() => TestBed.configureTestingModule({
			imports: [
				HttpClientTestingModule],
			providers: [{ provide: ToastService, useValue: ToastService }]
		}));
		it('should equal to  refresh token', inject([HttpTestingController, AuthService, ToastService], (
			httpMock: HttpTestingController,
			service: AuthService, ) => {
			let baseUrl = environment.SVC_ADMIN;
			// Make an HTTP request
			const tokenData = JSON.parse(sessionStorage.getItem('token'));
			let userInfo = JSON.parse(sessionStorage.getItem('userInfo'))
			let id = userInfo.id;
			service.refreshToken().subscribe(response => {
				// When observable resolves, result should match test data
				expect(response).toEqual(this.mockrefreshtoken);
			});
			const data = {
				user_id: 10,
				refreshToken: '593a4b75-6d56-4982-8a74-3a4ce9ccbb58'
			};
			// HTTP request mock
			const mockUrl = `${environment.SVC_AUTH_URL}${environment.api.refreshToken}`;
			const req = httpMock.expectOne(mockUrl);
			expect(req.request.method).toEqual('POST');
			req.flush(this.mockrefreshtoken);
			httpMock.verify();
		}));// RefreshToken

	});

	describe(' should call to the logout api', () => {
		beforeEach(() => TestBed.configureTestingModule({
			imports: [
				HttpClientTestingModule],
			providers: [{ provide: ToastService, useValue: ToastService }]
		}));
		it('should remove the token', inject([HttpTestingController, AuthService, ToastService], (
			httpMock: HttpTestingController,
			service: AuthService, ) => {
			let baseUrl = `${environment.SVC_AUTH_URL}${environment.api.logout}`;
			let demo = service.doLogout();
			if ([demo]) {
				let a = sessionStorage.removeItem('token');
			}

		})); // LogOutApi
	});


});
