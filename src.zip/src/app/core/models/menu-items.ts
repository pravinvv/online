import { RouteInfo } from "./sidebar.metadata";
export const ROUTES: RouteInfo[] = [
  {
    path: "/secured/dashboard",
    title: "Dashboard",
    icon: "mdi mdi-gauge",
    class: "",
    extralink: false,
    isOnlyFor: "all",
    submenu: []
  },
  {
    path: "organisation/list",
    title: "Organisations",
    icon: "as fa-building",
    class: "",
    extralink: false,
    isOnlyFor: "all",
    submenu: []
  },
  {
    path: "user/list",
    title: "User",
    icon: "mdi mdi-account",
    class: "",
    extralink: false,
    isOnlyFor: "all",
    submenu: []
  },
  {
    path: "staff/list",
    title: "Staffs",
    icon: "mdi mdi-account-multiple-plus",
    class: "",
    extralink: false,
    isOnlyFor: "all",
    submenu: []
  },

  {
    path: "faq/list",
    title: "FAQs",
    icon: "mdi mdi-bullseye",
    class: "",
    isOnlyFor: "all",
    extralink: false,
    submenu: []
  },
  {
    path: "product/list",
    title: "Products",
    icon: "mdi mdi-bullseye",
    class: "",
    isOnlyFor: "admin",
    extralink: false,
    submenu: []
  },
  {
    path: "chat",
    title: "Chat",
    icon: "mdi mdi-message",
    class: "",
    isOnlyFor: "agent",
    extralink: false,
    submenu: []
  }
];
