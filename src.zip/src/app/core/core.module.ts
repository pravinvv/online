import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { NavigationComponent } from './components/header-navigation/navigation.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { RouterModule } from '@angular/router';

import {
	PerfectScrollbarConfigInterface,
	PerfectScrollbarModule,
	PERFECT_SCROLLBAR_CONFIG,
} from 'ngx-perfect-scrollbar';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AuthenticationModule } from '../modules/authentication/authentication.module';
import { httpInterceptorProviders } from './interceptors';
import { SharedModule } from '../shared/shared.module';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
	suppressScrollX: true,
	wheelSpeed: 2,
	wheelPropagation: true,
	minScrollbarLength: 20,
};
@NgModule({
	declarations: [BreadcrumbComponent, NavigationComponent, SidebarComponent],
	imports: [CommonModule, RouterModule, PerfectScrollbarModule, NgbModule, AuthenticationModule,SharedModule],
	exports: [BreadcrumbComponent, NavigationComponent, SidebarComponent],
	providers: [
		{
			provide: PERFECT_SCROLLBAR_CONFIG,
			useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG,
		},
		httpInterceptorProviders
	],
})
export class CoreModule {}
