// Angular
import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

// Core Service
import { AuthService } from '../services/auth.service';
@Injectable()
export class AuthTokenInterceptor implements HttpInterceptor {
	constructor(private authService: AuthService) {}

	/**
	 * Intercept all outbound request and attach/skip headers based on the url.
	 * @param request outbound HTTP request object
	 * @param next HttpHandler
	 */
	intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
		/**
		 * Create the basic or bearer auth token
		 */

		const authTokenString = `Bearer ${this.authService.getToken}`;
		/**
		 * Skip adding the 'Content-Type'  header
		 */
		const headers = {
			Authorization: authTokenString,
		};

		/**
		 * Add authorization token for all API calls.
		 */
		const newRequest = request.clone({
			setHeaders: { ...headers },
		});
		return next.handle(newRequest);
	}
}
