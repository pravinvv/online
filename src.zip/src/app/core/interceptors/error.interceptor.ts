// Angular
import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, finalize, mergeMap, flatMap } from 'rxjs/operators';

// Core Service
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
	constructor(private authService: AuthService, private router: Router) {}

	intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
		return next.handle(request).pipe(
			catchError(err => {
				const error = err.error && err.error.message ? err.error : err;
				if (err instanceof HttpErrorResponse) {
					const responseString = error.message || '';
					if (
						(responseString.includes('jwt expired') || err.status === 401) &&
						!request.url.includes('refresh_token')
					) {
						return this.authService.refreshToken().pipe(
							flatMap((data: any) => {
								this.authService.setStorageInfo('token', data.token);
								request = request.clone({
									setHeaders: {
										Authorization: `Bearer ${this.authService.getToken}`,
									},
								});
								return next.handle(request);
							}),
							catchError(tokenError => {
								sessionStorage.clear();
								this.router.navigate(['/login']);
								return throwError(tokenError);
							})
						);
					}
				}

				return throwError(error);
			}),
			finalize(() => {})
		);
	}
}
