import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { StaffModel } from 'src/app/shared/models/staff.model';
import { throwError, Observable, of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ToastService } from 'src/app/shared/services/toast.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { mergeMap, toArray } from 'rxjs/operators';
@Injectable({
	providedIn: 'root',
})
export class StaffService {
	private baseUrl;
	constructor(private http: HttpClient, private authService: AuthService, private toast: ToastService) {
		this.baseUrl = environment.SVC_ADMIN;
	}
	private error(err) {
		err = err || {};
		this.toast.showError(err.message);
		return err.message;
	}

	getStaffList(): Observable<any> {
		const url = `${this.baseUrl}${environment.api.staffList}?includes=organisation,user`;
		return this.http
			.get<any>(url)
			.pipe(
				mergeMap((u: any) => {
					return u;
				}),
				mergeMap((s: any) => {
					s.organistionName = s.Organisation.name;
					s.name = `${s.User.first_name} ${s.User.last_name}`;

					return of(s);
				}),
				toArray()
			)
			.catch(err => throwError(this.error(err)));
	}
	createStaff(staff: StaffModel): Observable<StaffModel> {
		const url = `${this.baseUrl}${environment.api.createStaff}`;
		return this.http.post<StaffModel>(url, staff).catch(err => throwError(this.error(err)));
	}
	getSingleStaff(staffId: number): Observable<StaffModel> {
		let url = `${this.baseUrl}${environment.api.getSingleStaff}`;
		url = url.replace('{id}', staffId.toString());
		return this.http.get<StaffModel>(url).catch(err => throwError(this.error(err)));
	}

	updateStaff(staffId: number, staff: StaffModel): Observable<StaffModel> {
		let url = `${this.baseUrl}${environment.api.updateStaff}`;
		url = url.replace('{id}', staffId.toString());
		return this.http.put<StaffModel>(url, staff).catch(err => throwError(this.error(err)));
	}
	deleteStaff(staffId: number): Observable<HttpResponse<any>> {
		let url = `${this.baseUrl}${environment.api.deleteStaff}`;
		url = url.replace('{id}', staffId.toString());
		return this.http.delete<HttpResponse<any>>(url).catch(err => throwError(this.error(err)));
	}
}
