import { Component, OnInit } from '@angular/core';
import { StaffService } from '../../services/staff.service';
import { LoaderService } from 'src/app/shared/services/loader.service';
import { Router } from '@angular/router';
import { StaffModel } from 'src/app/shared/models/staff.model';

@Component({
	selector: 'app-staff-list-container',
	templateUrl: './staff-list-container.component.html',
	styleUrls: ['./staff-list-container.component.css'],
})
export class StaffListContainerComponent implements OnInit {
	public loaderId = 'app-staff-list';

	public setting = {
		columns: {
			name: {
				title: 'Name',
				addable: false,
				filter: {
					config: {
						inputClass: 'column-filter-1',
					},
				},
			},

			organistionName: {
				title: 'Organisation',
				addable: false,
				filter: {
					config: {
						inputClass: 'column-filter-2',
					},
				},
			},
			type: {
				title: 'Type',
				addable: false,
				filter: {
					config: {
						inputClass: 'column-filter-2',
					},
				},
			},
		},
		filter: {
			inputClass: 'column-filter-1',
		},
		actions: {
			add: false,
			edit: false,
			delete: false,
			custom: [
				{
					name: 'Edit',
					title: '<i class="ti-pencil text-info m-r-10"> ',
				},
			],
		},
	};
	public source: Array<StaffModel> = [];

	constructor(private router: Router, private staffService: StaffService, private loaderService: LoaderService) {}

	ngOnInit() {
		this.getStaff();
	}
	add() {
		this.router.navigate(['/secured/staff/create']);
	}
	edit(id) {
		this.router.navigate(['/secured/staff/edit', id]);
	}

	private getStaff() {
		this.loaderService.startLoader(this.loaderId);
		this.staffService.getStaffList().subscribe(
			(res: any) => {
				this.source = res;
				this.loaderService.stopLoader(this.loaderId);
			},
			() => {
				this.loaderService.stopLoader(this.loaderId);
			}
		);
	}
}
