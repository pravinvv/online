import { Component, OnInit } from '@angular/core';
import { UserInfoModel } from 'src/app/shared/models/user.model';
import { OrganisationModel } from 'src/app/shared/models/organisation.model';
import { UserService } from 'src/app/core/services/user.service';
import { OrganisationService } from 'src/app/modules/organisation/services/organisation.service';
import { mergeAll, map, mergeMap } from 'rxjs/operators';
import { forkJoin, of } from 'rxjs';
import { StaffService } from '../../services/staff.service';
import { StaffModel } from 'src/app/shared/models/staff.model';
import { ToastService } from 'src/app/shared/services/toast.service';
import { LoaderService } from 'src/app/shared/services/loader.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalService } from 'src/app/shared/services/modal.service';

@Component({
	selector: 'app-staff-create-container',
	templateUrl: './staff-create-container.component.html',
	styleUrls: ['./staff-create-container.component.css'],
})
export class StaffCreateContainerComponent implements OnInit {
	public loaderId = 'app-staff-info';
	public userList: Array<UserInfoModel>;
	public organisationList: Array<OrganisationModel>;
	public staffInfoModel: StaffModel;
	constructor(
		private userService: UserService,
		private staffService: StaffService,
		private orgService: OrganisationService,
		private toast: ToastService,
		private loaderService: LoaderService,
		private activatedRooute: ActivatedRoute,
		private modalService: ModalService,
		private router: Router
	) {}

	ngOnInit() {
		this.getUsersAndOrganisations();
	}

	private getUsersAndOrganisations() {
		this.loaderService.startLoader(this.loaderId);
		this.userService
			.getUserList()
			.pipe(
				map(u => {
					return forkJoin(of(u), this.orgService.getOrganisationList());
				}),
				mergeMap(s => {
					return s;
				})
			)
			.subscribe(
				result => {
					this.userList = result[0];
					this.organisationList = result[1];
					this.activatedRooute.params.subscribe(params => {
						if (params.id) {
							this.getstaffInfo(params.id);
						} else {
							this.loaderService.stopLoader(this.loaderId);
						}
					});
				},
				error => {
					this.loaderService.stopLoader(this.loaderId);
				}
			);
	}
	private getstaffInfo(staffId) {
		this.staffService.getSingleStaff(staffId).subscribe(
			staff => {
				this.staffInfoModel = staff;
				this.loaderService.stopLoader(this.loaderId);
			},
			error => {
				this.loaderService.stopLoader(this.loaderId);
			}
		);
	}

	actions(event: Map<string, any>) {
		const action = event.get('action');
		const data = event.get('data');
		switch (action) {
			case 'Create':
				this.addstaff(data);
				break;
			case 'Update':
				this.updatestaff(data);
				break;
			case 'Delete':
				this.deletestaff(data);
				break;
			case 'Cancel':
				this.router.navigate(['/secured/staff/list']);
				break;
			default:
				console.log('no actions');
		}
	}
	private updatestaff(staff: StaffModel) {
		this.staffService.updateStaff(staff.id, staff).subscribe((res: StaffModel) => {
			this.toast.showSuccess('staff Information updated Succesfully');
			this.router.navigate(['/secured/staff/list']);
		});
	}

	private deletestaff(data) {
		const staff: any = this.userList.find(u => u.id === data.user_id) || {};
		const modalRef = this.modalService.open({ name: 'confirmation', param: staff.name });
		modalRef.result.then(
			res => {
				if (res === 'Ok') {
					this.staffService.deleteStaff(data.id).subscribe((result: any) => {
						this.toast.showSuccess('staff information deleted.');
						this.router.navigate(['/secured/staff/list']);
					});
				}
			},
			() => {}
		);
	}
	private addstaff(staff: StaffModel) {
		this.staffService.createStaff(staff).subscribe((res: StaffModel) => {
			this.toast.showSuccess('staff Created Successfully');
			this.router.navigate(['/secured/staff/list']);
		});
	}
}
