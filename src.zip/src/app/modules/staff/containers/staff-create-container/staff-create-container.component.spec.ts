import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffCreateContainerComponent } from './staff-create-container.component';

describe('StaffCreateContainerComponent', () => {
  let component: StaffCreateContainerComponent;
  let fixture: ComponentFixture<StaffCreateContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StaffCreateContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffCreateContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
