import { Routes } from '@angular/router';
import { StaffCreateContainerComponent } from './containers/staff-create-container/staff-create-container.component';
import { StaffListContainerComponent } from './containers/staff-list-container/staff-list-container.component';

export const StaffRoutes: Routes = [
	{
		path: '',
		children: [
			{
				path: 'create',
				component: StaffCreateContainerComponent,
				data: {
					title: 'Create',
					urls: [{ title: 'Add Staff', url: 'staff/create' }, { title: 'Add Staff' }],
				},
			},
			{
				path: 'edit/:id',
				component: StaffCreateContainerComponent,
				data: {
					title: 'Edit',
					urls: [{ title: 'Edit staff', url: 'staff/edit/:id' }, { title: 'Edit staff' }],
				},
			},
			{
				path: 'list',
				component: StaffListContainerComponent,
				data: {
					title: 'List',
					urls: [{ title: 'staff List', url: 'staff/list' }, { title: 'staff List' }],
				},
			},
		],
	},
];
