import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StaffCreateContainerComponent } from './containers/staff-create-container/staff-create-container.component';
import { StaffListContainerComponent } from './containers/staff-list-container/staff-list-container.component';
import { StaffFormComponent } from './components/staff-form/staff-form.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { RouterModule } from '@angular/router';
import { StaffRoutes } from './staff.routing';

@NgModule({
	declarations: [StaffCreateContainerComponent, StaffListContainerComponent, StaffFormComponent],
	imports: [CommonModule, NgbModule, FormsModule, SharedModule, RouterModule.forChild(StaffRoutes)],
})
export class StaffModule {}
