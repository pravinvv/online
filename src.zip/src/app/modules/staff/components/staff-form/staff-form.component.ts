import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { StaffModel } from 'src/app/shared/models/staff.model';
import { NgForm } from '@angular/forms';
import { OrganisationModel } from 'src/app/shared/models/organisation.model';
import { UserInfoModel } from 'src/app/shared/models/user.model';

@Component({
	selector: 'app-staff-form',
	templateUrl: './staff-form.component.html',
	styleUrls: ['./staff-form.component.css'],
})
export class StaffFormComponent implements OnInit {
	public isEdit = true;
	public userList: Array<UserInfoModel>;
	public organisationList: Array<OrganisationModel>;

	public staffModel: StaffModel = {
		id: null,
		user_id: '',
		organisation_id: '',
		status: 'active',
		type: 'agent',
		request_handling: 0,
	};
	@Input('organisationList') private set organisations(data: Array<OrganisationModel>) {
		if (data) {
			this.organisationList = data;
		}
	}
	@Input('userList') private set users(data: Array<UserInfoModel>) {
		if (data) {
			this.userList = data;
		}
	}
	@Input('staffInfo') private set staff(data: StaffModel) {
		if (data) {
			this.staffModel = data;
			this.staffModel.status = 'active';
			this.isEdit = true;
		} else {
			this.isEdit = false;
		}
	}

	@Output() private actions: EventEmitter<Map<string, any>> = new EventEmitter<Map<string, any>>();

	constructor() {}

	ngOnInit() {}

	submitForm(form: NgForm) {
		if (form.valid) {
			const actionData = new Map();
			actionData.set('action', this.isEdit ? 'Update' : 'Create');
			actionData.set('data', this.staffModel);
			this.actions.emit(actionData);
		}
	}
	deleteStaff() {
		const actionData = new Map();
		actionData.set('action', 'Delete');
		actionData.set('data', this.staffModel);
		this.actions.emit(actionData);
	}
	cancel() {
		const actionData = new Map();
		actionData.set('action', 'Cancel');
		actionData.set('data', this.staffModel.id);
		this.actions.emit(actionData);
	}
}
