import { Routes } from '@angular/router';

import { CreateContainerComponent } from './containers/create-container/create-container.component';
import {ListContainerComponent} from './containers/list-container/list-container.component';

export const OrganisationRoutes: Routes = [
	{
		path: '',
		children: [
			{
				path: 'create',
				component: CreateContainerComponent,
				data: {
					title: 'Create',
					urls: [{ title: 'Add Organisation', url: 'organisation/create' }, { title: 'Add Organisation' }],
				},
			},
			{
				path: 'edit/:id',
				component: CreateContainerComponent,
				data: {
					title: 'Edit',
					urls: [{ title: 'Edit Organisation', url: 'organisation/edit/:id' }, { title: 'Edit Organisation' }],
				},
			},
			{
				path: 'list',
				component: ListContainerComponent,
				data: {
					title: 'List',
					urls: [{ title: 'List Organisation', url: 'organisation/list' }, { title: 'List Organisation' }],
				},
			},

		],
	},
];
