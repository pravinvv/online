import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateContainerComponent } from './containers/create-container/create-container.component';
import { RouterModule } from '@angular/router';
import { OrganisationRoutes } from './organisation.routing';
import { FormComponent } from './components/form/form.component';
import { ListContainerComponent } from './containers/list-container/list-container.component';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
	declarations: [CreateContainerComponent, FormComponent, ListContainerComponent],
	imports: [
		CommonModule,
		RouterModule.forChild(OrganisationRoutes),
		NgbModule,
		FormsModule,
		SharedModule,
	],
})
export class OrganisationModule {}
