import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { OrganisationModel } from '../../../shared/models/organisation.model';
import { Observable, throwError } from 'rxjs';
import 'rxjs/add/operator/catch';
import { ToastService } from '../../../shared/services/toast.service';
@Injectable({
	providedIn: 'root',
})
export class OrganisationService {
	private baseUrl;
	constructor(private http: HttpClient, private toast: ToastService) {
		this.baseUrl = environment.SVC_ADMIN;
	}
	private error(err) {
		err = err || {};
		this.toast.showError(err.message);
		return err.message;
	}
	createOrganisation(org: OrganisationModel): Observable<OrganisationModel> {
		const url = `${this.baseUrl}${environment.api.createOrganisation}`;
		return this.http.post<OrganisationModel>(url, org).catch(err => throwError(this.error(err)));
	}

	updateOrganisation(orgId: number, org: OrganisationModel): Observable<OrganisationModel> {
		let url = `${this.baseUrl}${environment.api.updateOrganisation}`;
		url = url.replace('{id}', orgId.toString());
		return this.http.put<OrganisationModel>(url, org).catch(err => throwError(this.error(err)));
	}
	getOrganisationList(): Observable<Array<OrganisationModel>> {
		const url = `${this.baseUrl}${environment.api.listOrganisation}?include=owner`;
		return this.http.get<Array<OrganisationModel>>(url).catch(err => throwError(this.error(err)));
	}

	getSingleOrganisation(orgId: number): Observable<OrganisationModel> {
		let url = `${this.baseUrl}${environment.api.getSingleOrganisation}`;
		url = url.replace('{id}', orgId.toString());

		return this.http.get<OrganisationModel>(url).catch(err => throwError(this.error(err)));
	}
	deleteOrganisation(orgId: number): Observable<HttpResponse<any>> {
		let url = `${this.baseUrl}${environment.api.deleteOrganisation}`;
		url = url.replace('{id}', orgId.toString());

		return this.http.delete<HttpResponse<any>>(url).catch(err => throwError(this.error(err)));
	}
	// getStaff(orgId: number): Observable<HttpResponse<any>> {
	// 	const url = `${this.baseUrl}${environment.api.getStaffByOrgId}/${orgId}`;
	// 	return this.http.delete<HttpResponse<any>>(url).catch(err => throwError(this.error(err)));
	// }
	// getUser(orgId: number): Observable<HttpResponse<any>> {
	// 	const url = `${this.baseUrl}${environment.api.getUser}/${orgId}`;
	// 	return this.http.delete<HttpResponse<any>>(url).catch(err => throwError(this.error(err)));
	// }
}
