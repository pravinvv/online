import { TestBed, inject, async } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { OrganisationService } from './organisation.service';
import { environment } from '../../../../environments/environment';
import { ToastService } from 'src/app/shared/services/toast.service';
import * as getorganisationlist from '../../../../spec/mock/modules/organisation/service/get-organisation-list.json';
import * as getsingleorganisation from '../../../../spec/mock/modules/organisation/service/get-single-organisation.json';
import * as updateorganisation from '../../../../spec/mock/modules/organisation/service/update-organisation.json';
import * as deleteorganisation from '../../../../spec/mock/modules/organisation/service/delete-organisation.json';
import * as createorganisation from '../../../../spec/mock/modules/organisation/service/create-organisation.json';

describe('OrganisationService', () => {
	beforeEach(() => TestBed.configureTestingModule({
		imports: [
			HttpClientTestingModule],
		providers: [{ provide: ToastService, useValue: ToastService }]
	}));

	beforeEach(() => {
		this.mockgetorganisationlist = getorganisationlist;
		this.mockgetsingleorganisation = getsingleorganisation.id;
		this.mockgetsingleorganisation = getsingleorganisation;
		this.mockupdatesingleorganisationwithname = updateorganisation.name;
		this.mockupdatesingleorganisation = updateorganisation;
		this.mockdeleteorganisationid = deleteorganisation.id;
		this.mockdeleteorganisation = deleteorganisation;
		this.mockcreateorganisation = createorganisation;

	});

	it(`should create`, async(inject([HttpTestingController, OrganisationService],
		(httpClient: HttpTestingController, apiService: OrganisationService) => {
			expect(apiService).toBeTruthy();
		})));

	it('getOrganisationList', inject([OrganisationService], (service: OrganisationService) => {
		expect(service.getOrganisationList()).toBeTruthy();
	}));

	describe('getOrganisationList should call api', () => {
		beforeEach(() => TestBed.configureTestingModule({
			imports: [
				HttpClientTestingModule],
			providers: [{ provide: ToastService, useValue: ToastService }]
		}));

		it('should return the organisationList', inject([HttpTestingController, OrganisationService, ToastService], (
			httpMock: HttpTestingController,
			service: OrganisationService, ) => {
			let baseUrl = environment.SVC_ADMIN;
			// Make an HTTP request
			service.getOrganisationList().subscribe(response => {
				// When observable resolves, result should match test data
				expect(response).toEqual(this.mockgetorganisationlist);
			});
			// HTTP request mock
			const mockUrl = `${baseUrl}${environment.api.listOrganisation}?include=owner`;;
			const req = httpMock.expectOne(mockUrl);
			expect(req.request.method).toEqual('GET');
			req.flush(this.mockgetorganisationlist);
			httpMock.verify();
		}));

	}); // getOrganisationList

	describe('getSingle OrganisationList should call api', () => {
		beforeEach(() => TestBed.configureTestingModule({
			imports: [
				HttpClientTestingModule],
			providers: [{ provide: ToastService, useValue: ToastService }]
		}));

		it('should return the  single organisationRecord', inject([HttpTestingController, OrganisationService, ToastService], (
			httpMock: HttpTestingController,
			service: OrganisationService, ) => {
			let baseUrl = environment.SVC_ADMIN;
			// Make an HTTP request
			service.getSingleOrganisation(this.mockgetsingleorganisation.id).subscribe(response => {
				// When observable resolves, result should match test data
				expect(response).toEqual(this.mockgetsingleorganisation);
			});
			// HTTP request mock
			const mockUrl = `${baseUrl}${environment.api.getSingleOrganisation}`;
			let url = mockUrl.replace('{id}', this.mockgetsingleorganisation.id.toString());
			const req = httpMock.expectOne(url);
			expect(req.request.method).toEqual('GET');
			req.flush(this.mockgetsingleorganisation);
			httpMock.verify();
		}));
	}); // getSingleOrganisation

	describe('should call to update api', () => {
		beforeEach(() => TestBed.configureTestingModule({
			imports: [
				HttpClientTestingModule],
			providers: [{ provide: ToastService, useValue: ToastService }]
		}));
		it('should return the  updated record of specific id', inject([HttpTestingController, OrganisationService, ToastService], (
			httpMock: HttpTestingController,
			service: OrganisationService, ) => {
			let baseUrl = environment.SVC_ADMIN;
			// Make an HTTP request
			service.updateOrganisation(this.mockgetsingleorganisation.id, this.mockupdatesingleorganisation).subscribe(response => {
				// When observable resolves, result should match test data
				expect(response).toEqual(this.mockupdatesingleorganisation);
			});
			// HTTP request mock
			const mockUrl = `${baseUrl}${environment.api.updateOrganisation}`;
			let url = mockUrl.replace('{id}', this.mockgetsingleorganisation.id.toString());
			const req = httpMock.expectOne(url);
			expect(req.request.method).toEqual('PUT');
			req.flush(this.mockupdatesingleorganisation);
			httpMock.verify();
		}));
	}); // Update Organisation

	describe('should call to delete api', () => {
		beforeEach(() => TestBed.configureTestingModule({
			imports: [
				HttpClientTestingModule],
			providers: [{ provide: ToastService, useValue: ToastService }]
		}));

		it('should return the  delete the record', inject([HttpTestingController, OrganisationService, ToastService], (
			httpMock: HttpTestingController,
			service: OrganisationService, ) => {
			let baseUrl = environment.SVC_ADMIN;
			// Make an HTTP request
			service.deleteOrganisation(this.mockdeleteorganisationid).subscribe(response => {
				// When observable resolves, result should match test data
				expect(response).toEqual(this.mockdeleteorganisation);
			});
			// HTTP request mock
			const mockUrl = `${baseUrl}${environment.api.deleteOrganisation}`;
			let url = mockUrl.replace('{id}', this.mockdeleteorganisationid.toString());
			const req = httpMock.expectOne(url);
			expect(req.request.method).toEqual('DELETE');
			req.flush(this.mockdeleteorganisation);
			httpMock.verify();
		}));
	}); // Delete Organisation

	describe('should call to post api', () => {
		beforeEach(() => TestBed.configureTestingModule({
			imports: [
				HttpClientTestingModule],
			providers: [{ provide: ToastService, useValue: ToastService }]
		}));
		it('should create the organisation', inject([HttpTestingController, OrganisationService, ToastService], (
			httpMock: HttpTestingController,
			service: OrganisationService, ) => {
			let baseUrl = environment.SVC_ADMIN;
			// Make an HTTP request
			service.createOrganisation(this.mockcreateorganisation).subscribe(response => {
				// When observable resolves, result should match test data
				expect(response).toEqual(this.mockcreateorganisation);
			});
			// HTTP request mock
			const mockUrl = `${baseUrl}${environment.api.createOrganisation}`;
			const req = httpMock.expectOne(mockUrl);
			expect(req.request.method).toEqual('POST');
			req.flush(this.mockcreateorganisation);
			httpMock.verify();
		}));
	}); // Create  Organisation

});
