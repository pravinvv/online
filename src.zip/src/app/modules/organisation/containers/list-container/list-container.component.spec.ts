import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ListContainerComponent } from './list-container.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ToastService } from 'src/app/shared/services/toast.service';
import { SpinnerComponent } from 'src/app/shared/components/spinner/spinner.component';
import { ListComponent } from 'src/app/shared/components/list/list.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { OrganisationService } from '../../services/organisation.service';


describe('ListContainerComponent', () => {
	let component: ListContainerComponent;
	let fixture: ComponentFixture<ListContainerComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [RouterTestingModule, HttpClientTestingModule],
			declarations: [ListContainerComponent, SpinnerComponent, ListComponent],
			schemas: [NO_ERRORS_SCHEMA],
			providers: [{ provide: ToastService, useValue: ToastService }]
		})
			.compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ListContainerComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('able to display list', inject([OrganisationService], (service: OrganisationService) => {
		expect(service.getOrganisationList()).toBeTruthy();
	}));


	it('list shows correctly', inject([OrganisationService], (service: OrganisationService) => {
		expect(service.getOrganisationList().subscribe(data => {

			expect(data.length).toBeGreaterThan(0);

		})).toBeTruthy();
	}));
});
