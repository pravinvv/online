import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrganisationService } from '../../services/organisation.service';
import { OrganisationModel } from '../../../../shared/models/organisation.model';
import { mergeMap, map, toArray } from 'rxjs/operators';
import { LoaderService } from 'src/app/shared/services/loader.service';
import { of } from 'rxjs';

@Component({
	selector: 'app-list-container',
	templateUrl: './list-container.component.html',
	styleUrls: ['./list-container.component.css'],
})
export class ListContainerComponent implements OnInit {
	public setting = {
		columns: {
			name: {
				title: 'Name',
				addable: false,
				filter: {
					config: {
						inputClass:'column-filter-1'
					}
				}				
			},
			status: {
				title: 'Status',
				addable: false,
				filter: {
					config: {
						inputClass:'column-filter-2'
					}
				}				
			},
			owner: {
				title: 'Owner',
				addable: false,
				filter: {
					config: {
						inputClass:'column-filter-3'
					}
				}				
			},
		},
		filter: {
			inputClass:'column-filter-1'
		},				
		actions: {
			add: false,
			edit: false,
			delete: false,
			custom: [
				{
					name: 'Edit',
					title: '<i class="ti-pencil text-info m-r-10"> ',
				},
			],
		},
	};
	public source: Array<OrganisationModel> = [];
	constructor(
		private router: Router,
		private orgService: OrganisationService,
		private loaderService: LoaderService
	) {}

	ngOnInit() {
		this.getOrganisationList();
	}
	add() {
		 this.router.navigate(['/secured/organisation/create']);
	}
	edit(id) {
		this.router.navigate(['/secured/organisation/edit', id]);
	}
	delete(id) {
		 this.router.navigate(['organisation/edit', id]);
		alert(`Custom event delete fired on row №: ${id}`);
	}

	getOrganisationList() {
		this.loaderService.startLoader('app-org-list');
		this.orgService
			.getOrganisationList()
			.pipe(
				mergeMap(param => {
					return param;
				}),
				mergeMap((p: any) => {
					p.owner = (((p.Staff || [])[0] || {}).User || {}).email;
					delete p.Staff;
					return of(p);
				}),
				toArray()
			)
			.subscribe(
				(res: any) => {
					this.source = res;
					this.loaderService.stopLoader('app-org-list');
				},
				err => {
					this.loaderService.stopLoader('app-org-list');
				}
			);
	}
}
