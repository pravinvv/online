import { Component, OnInit } from '@angular/core';
import { OrganisationModel } from '../../../../shared/models/organisation.model';
import { OrganisationService } from '../../services/organisation.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from '../../../../shared/services/toast.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { LoaderService } from 'src/app/shared/services/loader.service';

@Component({
	selector: 'app-create-container',
	templateUrl: './create-container.component.html',
	styleUrls: ['./create-container.component.css'],
})
export class CreateContainerComponent implements OnInit {
	public organisation: OrganisationModel;
	public loaderId = 'app-create';
	constructor(
		private orgService: OrganisationService,
		private router: Router,
		private activatedRoute: ActivatedRoute,
		private toast: ToastService,
		private modalService: ModalService,
		private loaderService: LoaderService
	) {}
	ngOnInit() {
		this.activatedRoute.params.subscribe(params => {
			if (params.id) {
				this.getSingleOrganisation(params.id);
			}
		});
	}
	createOrganisation(organisation: OrganisationModel) {
		this.orgService.createOrganisation(organisation).subscribe((res: OrganisationModel) => {
			this.toast.showSuccess('Organisation information created.');
			this.router.navigate(['/secured/organisation/list']);
		});
	}
	updateOrganisation(organisation: OrganisationModel) {
		this.orgService.updateOrganisation(organisation.id, organisation).subscribe((res: OrganisationModel) => {
			this.toast.showSuccess('Organisation information updated.');
			this.router.navigate(['/secured/organisation/list']);
		});
	}
	deleteOrganisation(orgId: number) {
		const modalRef = this.modalService.open({ name: 'confirmation', param: this.organisation.name });
		modalRef.result.then(
			res => {
				if (res === 'Ok') {
					this.orgService.deleteOrganisation(orgId).subscribe((result: any) => {
						this.toast.showSuccess('Organisation information deleted.');
						this.router.navigate(['/secured/organisation/list']);
 				});
				}
			},
			() => {}
		);
	}
	getSingleOrganisation(orgId: number) {
		this.loaderService.startLoader(this.loaderId);
		this.orgService.getSingleOrganisation(orgId).subscribe((res: OrganisationModel) => {
			this.organisation = res;
			this.loaderService.stopLoader(this.loaderId);
		});
	}
}
