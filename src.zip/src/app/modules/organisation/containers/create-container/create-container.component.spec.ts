import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateContainerComponent } from './create-container.component';
import { SpinnerComponent } from 'src/app/shared/components/spinner/spinner.component';
import { FormComponent } from '../../components/form/form.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgbTabsetModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ToastService } from 'src/app/shared/services/toast.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('CreateContainerComponent', () => {
    let component: CreateContainerComponent;
    let fixture: ComponentFixture<CreateContainerComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CreateContainerComponent, SpinnerComponent, FormComponent],
            schemas: [NO_ERRORS_SCHEMA],
            imports: [FormsModule, NgbTabsetModule, HttpClientTestingModule, RouterTestingModule],
            providers: [{ provide: ToastService, useValue: ToastService }]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(CreateContainerComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create create-container ', () => {
        expect(component).toBeTruthy();
    });
});
