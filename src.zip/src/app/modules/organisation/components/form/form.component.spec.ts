import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import * as uuid from 'uuid';
import { FormComponent } from './form.component';
import { By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbTabsetModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { OrganisationService } from '../../services/organisation.service';
import { ToastService } from 'src/app/shared/services/toast.service';

describe('FormComponent', () => {

    const mockData: any = {
        id: 9,
        name: 'swarup',
        status: 'active',
        workspace_id: uuid.v4()
    };


    let component: FormComponent;
    let fixture: ComponentFixture<FormComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [FormComponent],
            imports: [ReactiveFormsModule, NgbTabsetModule, FormsModule, HttpClientTestingModule],
            schemas: [NO_ERRORS_SCHEMA],
            providers: [{ provide: ToastService, useValue: ToastService }]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(FormComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create form component', () => {
        expect(component).toBeTruthy();
    });

    it('should Able to View Create UI  ', () => {
        let de = fixture.debugElement.query(By.css('#name'));
        expect(de).toBeTruthy();
    });

    it('should Able to View dropdown active,inactive  ', () => {
        let de = fixture.debugElement.query(By.css('#status'));
        expect(de).toBeTruthy();
    });

    it('should Able to see Basic Tab ', () => {
        let de = fixture.debugElement.query(By.css('#tabset'));
        expect(de).toBeTruthy();
    });

    it('should Able to see Advanced Tab ', () => {
        let de = fixture.debugElement.query(By.css('#tab2'));
        expect(de).toBeTruthy();
    });

    it('should ot be  Able to see Workspace-Id directly  ', () => {
        let de = fixture.debugElement.query(By.css('#workspace'));
        expect(de).toBeFalsy();
    });

    it('should be able to save data.', inject([OrganisationService], (service: OrganisationService) => {
        expect(service.createOrganisation(mockData.id)
            .subscribe(data => {
                expect(data.name).toEqual('swarup');
                expect(data.status).toEqual('active');
            }));
    }));

    it('should Able to change name field in basic tab ', () => {
        const data = 'swarup';
        fixture.whenStable().then(() => {
            const dataEle = component.basicForm.controls['name'];
            dataEle.setValue(data);
            expect(dataEle.value).toEqual(data);
        });
    });

    it('should Able to change active status  field in basic tab ', () => {
        const data = 'acive';
        fixture.whenStable().then(() => {
            const dataEle = component.basicForm.controls['status'];
            dataEle.setValue(data);
            expect(dataEle.value).toEqual(data);
        });
    });

    it('should Able to change inactive  field in basic tab ', () => {
        const data = 'inactive';
        fixture.whenStable().then(() => {
            const dataEle = component.basicForm.controls['status'];
            dataEle.setValue(data);
            expect(dataEle.value).toEqual(data);
        });
    });

    it('should Able to change workspace id which is genrated by uuid  in advanced tab ', () => {
        const data = mockData.workspace_id;
        fixture.whenStable().then(() => {
            const dataEle = component.basicForm.controls['workspace-id'];
            dataEle.setValue(data);
            expect(dataEle.value).toEqual(data);
        });
    });

    /* Test Cases For Edit as we have two components are common */

    it('should Able to see Basic Tab and having value in each field', () => {
        let de = fixture.debugElement.query(By.css('#tabset'));
        expect(de).toBeTruthy();
    });

    it('should Able to View Edit UI  ', () => {
        let de = fixture.debugElement.query(By.css('#name'));
        expect(de).toBeTruthy();
    }); /*for Basic Tab */

    it('should Able to  View and edit dropdown active,inactive  ', () => {
        let de = fixture.debugElement.query(By.css('#status'));
        expect(de).toBeTruthy();
    });    /*for Basic Tab */

    /*For Advanced Tab */

    it('should Able to see Advanced Tab and having value in  each field ', () => {
        let de = fixture.debugElement.query(By.css('#tab2'));
        expect(de).toBeTruthy();
    });

    it('should ot be  Able to see Workspace-Id directly in edit view   ', () => {
        let de = fixture.debugElement.query(By.css('#workspace'));
        expect(de).toBeFalsy();    /* end of Advanced Tab and */
    });

    /*User Should Changed all fields in Edit */

    it('should Able to Edit name field in basic tab ', () => {
        const data = 'swarup';
        fixture.whenStable().then(() => {
            const dataEle = component.basicForm.controls['name'];
            dataEle.setValue(data);
            expect(dataEle.value).toEqual(data);
        });
    });

    it('should Able to edit active status  field in basic tab ', () => {
        const data = 'acive';
        fixture.whenStable().then(() => {
            const dataEle = component.basicForm.controls['status'];
            dataEle.setValue(data);
            expect(dataEle.value).toEqual(data);
        });
    });

    it('should Able to edit inactive status  field in basic tab ', () => {
        const data = 'acive';
        fixture.whenStable().then(() => {
            const dataEle = component.basicForm.controls['status'];
            dataEle.setValue(data);
            expect(dataEle.value).toEqual(data);
        });
    });

    it('should Able to edit  workspace id in advanced tab ', () => {
        const data = mockData.workspace_id;
        fixture.whenStable().then(() => {
            const dataEle = component.basicForm.controls['workspace-id'];
            dataEle.setValue(data);
            expect(dataEle.value).toEqual(data);
        });
    });

    it('should be able to save in edit view', async(() => {
        spyOn(component, 'save');
        const button = fixture.debugElement.nativeElement.querySelector('button');
        button.click();
        fixture.whenStable().then(() => {
            expect(component.save).toHaveBeenCalled();
        });
    }));
    it('UpdateOrganisation should be', inject([OrganisationService], (service: OrganisationService) => {
        expect(service.updateOrganisation(mockData.id, mockData)).toBeTruthy();
    }));

    it('Response should be equal to format of mockData', inject([OrganisationService], (service: OrganisationService) => {
        expect(service.updateOrganisation(mockData.id, mockData).subscribe(data => {
            expect(data).toEqual(mockData);
        }));
    }));
});
