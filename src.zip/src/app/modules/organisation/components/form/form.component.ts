import {Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {OrganisationModel} from '../../../../shared/models/organisation.model';
import {NgForm} from '@angular/forms';
import {NgbTabset} from '@ng-bootstrap/ng-bootstrap';

@Component({
	selector: 'app-form',
	templateUrl: './form.component.html',
	styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

	@Input('orgnisation')
	private set org(data) {
		if (data) {
			this.organisationModel = data;
		}
	}
	@Output() private delete: EventEmitter<number> = new EventEmitter<number>();
	@Output() private update: EventEmitter<OrganisationModel> = new EventEmitter<OrganisationModel>();
	@Output() private create: EventEmitter<OrganisationModel> = new EventEmitter<OrganisationModel>();

	public  organisationModel: OrganisationModel = {id: null, name: '', status: 'active', workspace_id: ''};
	public activeTab = 'tab1';
	@ViewChild('basicForm')
	public basicForm: NgForm;
	@ViewChild('advanceForm')
	public advanceForm: NgForm;
	@ViewChild('t')
	private t: NgbTabset;
	constructor() { }

	ngOnInit() {
	}
	submitForm(form: NgForm) {
		if (form.valid && !this.organisationModel.id) {
			this.create.emit(this.organisationModel);
		}
		if (form.valid && this.organisationModel.id) {
			const id = this.organisationModel.id;
			this.update.emit({...this.organisationModel, id});
		}
		if (this.activeTab === 'tab1') {
			this.activeTab = 'tab2';
		} else if (this.activeTab === 'tab2') {
			this.activeTab = 'tab1';
		}
		this.t.select(this.activeTab);
	}

	deleteOrganisation() {
		if (this.organisationModel.id) {
			this.delete.emit(this.organisationModel.id);
		}
	}
	tabChange(event) {

		if (event.nextId === 'tab2' && this.basicForm.invalid) {
			event.preventDefault();
		} else {
			this.activeTab = event.nextId;
		}
	}
	save() {
		if (this.advanceForm && this.advanceForm.valid) {
			if (this.activeTab === 'tab1') {
				this.submitForm(this.basicForm);
			}
			if (this.activeTab === 'tab2') {
				this.submitForm(this.advanceForm);
			}
		}

	}

}
