import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ProductFormComponent } from './product-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ProductModel } from 'src/app/shared/models/product.model';

describe('ProductFormComponent', () => {
  const mockData: ProductModel = {
    id: 4,
    name: "Product D",
    description: "Product D Description",
    image_url: "http://via.placeholder.com/140x140",
    organisation_id: 1,
    created_at: new Date("2019-05-21T05:13:26.754Z"),
    updated_at: new Date("2019-05-21T05:13:26.754Z"),
    nego_params: [
      {
        name: "price",
        min: 9,
        baseline: 100,
        weight: 0.2,
        inverse: false
      }
    ]
  }

  let component: ProductFormComponent;
  let fixture: ComponentFixture<ProductFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ProductFormComponent],
      imports: [FormsModule, ReactiveFormsModule],
      schemas: [NO_ERRORS_SCHEMA],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductFormComponent);
    component = fixture.componentInstance;
    component.productModel = mockData;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should Able to change Product name in edit view ', () => {
    const data = 'swarup';
    fixture.whenStable().then(() => {
      const dataEle = component.productForm.controls['Name'];
      dataEle.setValue(data);
      expect(dataEle.value).toEqual(data);
    });
  });

  it('should be  Able to change description in product description in product. ', () => {
    const data = 'swarup';
    fixture.whenStable().then(() => {
      const dataEle = component.productForm.controls['description'];
      dataEle.setValue(data);
      expect(dataEle.value).toEqual(data);
    });
  });

  it('should be  Able to change price in product description in product view. ', () => {
    const data = '10';
    fixture.whenStable().then(() => {
      const inputElement = fixture.debugElement.query(By.css('.nameInput')).nativeElement;
      inputElement.value = '10';
      expect(inputElement.value).toEqual(data);
    });
  });

  it('should be  Able to change Image in Product View', () => {
    const data = 'http://via.placeholder.com/140x140';
    fixture.whenStable().then(() => {
      const inputElement = fixture.debugElement.query(By.css('.imageBlock')).nativeElement;
      inputElement.value = 'http://via.placeholder.com/140x140';
      expect(inputElement.value).toEqual(data);
    });
  });

  it('should be  Able to change price in product description in product view. ', () => {
    const data = '10';
    fixture.whenStable().then(() => {
      const inputElement = fixture.debugElement.query(By.css('.nameInput')).nativeElement;
      inputElement.value = '10';
      expect(inputElement.value).toEqual(data);
    });
  });

  it('should be  Able to change price of the product in product view. ', () => {
    const price = 10;
    fixture.whenStable().then(() => {
      const dataEle = component.productForm.controls['name'];
      dataEle.setValue(price);
      expect(dataEle.value).toEqual(price);
    });
  });

  it('should call save  on form submit in product view', () => {
    const button = fixture.debugElement.nativeElement.querySelector('#submit');
    button.click();
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    // Supply id of your form below formID
    const getForm = fixture.debugElement.query(By.css('#productForm'));
    expect(getForm.triggerEventHandler('submit', compiled)).toBeUndefined();
  });

  it('should be able to cancel in product view', async(() => {
    spyOn(component, 'cancel');
    const button = fixture.debugElement.nativeElement.querySelector('#cancel');
    button.click();
    fixture.whenStable().then(() => {
      expect(component.cancel).toHaveBeenCalled();
    });
  }));
  it("should be able to delete in product view.", () => {
    spyOn(component, "deleteProduct")
    component.isEdit = true;
    fixture.detectChanges();
    let el = fixture.debugElement.query(By.css('#deleteProduct'))
    el.triggerEventHandler('click', null)
    fixture.detectChanges()
    fixture.whenStable().then(() => {
      expect(component.deleteProduct).toHaveBeenCalled();
    });
  });

  it('should Able to View Create Product Name in  Product Edit View ', () => {
    let de = fixture.debugElement.query(By.css('#Name'));
    expect(de).toBeTruthy();
  });
  it('should Able to  Create Product Description in  Product Edit View', () => {
    let de = fixture.debugElement.query(By.css('#description'));
    expect(de).toBeTruthy();
  });
  it('should Able to  see Image in Product view ', () => {
    let de = fixture.debugElement.query(By.css('#img'));
    expect(de).toBeTruthy();
  });
  it('should Able to  see Price  in Product view', () => {
    let de = fixture.debugElement.query(By.css('.nameInput'));
    expect(de).toBeTruthy();
  });
  it('should Able to  see Minimum Price  in Product view', () => {
    let de = fixture.debugElement.query(By.css('.minpriceInput'));
    expect(de).toBeTruthy();
  });
  it('should Able to  Weight  in Product view', () => {
    let de = fixture.debugElement.query(By.css('.negoweightInput'));
    expect(de).toBeTruthy();
  });

});
