import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { ProductModel } from 'src/app/shared/models/product.model';
import { NgForm } from '@angular/forms';

@Component({
	selector: 'app-product-form',
	templateUrl: './product-form.component.html',
	styleUrls: ['./product-form.component.css'],
})
export class ProductFormComponent implements OnInit {
	public productModel: ProductModel;
	private file: File;
	public isEdit: boolean;

	public negoParamsTitles = [
		{
			firstTitle: 'Price',
			secondTitle: 'Min.Price',
			fifthTitle: 'Max.Price',
			thirdTitle: 'Nego. Weigth ?',
			fourthTitle: 'Inverse Weight ?',
		},
		{
			firstTitle: 'Ideal Quantity',
			secondTitle: 'Min.Quantity',
			fifthTitle: 'Max. Quantity',
			thirdTitle: 'Nego. Weigtht',
			fourthTitle: 'Inverse Weight',
		},
		{
			firstTitle: 'Ideal Lead Time(days)',
			secondTitle: 'Min. Lead time',
			fifthTitle: 'Max. Lead time',
			thirdTitle: 'Nego. Weigtht',
			fourthTitle: 'Inverse Weight',
		},
		{
			firstTitle: 'Payment Term (days)',
			secondTitle: 'Min. Term',
			thirdTitle: 'Nego. Weigtht',
			fourthTitle: 'Inverse Weight',
			fifthTitle: 'Max. Term',
		},
	];

	@Input('productModel') private set data(model: ProductModel) {
		if (model) {
			this.productModel = model;
			this.productModel.nego_params = this.checkNegoParams(this.productModel.nego_params);
			this.isEdit = true;
		} else {
			this.isEdit = false;
			this.productModel = {
				id: null,
				organisation_id: 1,
				name: '',
				image_url: '',
				description: '',
				nego_params: this.checkNegoParams([]),
			};
		}
	}
	@Input('image_url') private set image(imageUrl: string) {
		if (imageUrl) {
			this.productModel.image_url = imageUrl;
			this.file = null;
		}
	}
	@Output() private delete: EventEmitter<number> = new EventEmitter<number>();
	@Output() private update: EventEmitter<ProductModel> = new EventEmitter<ProductModel>();
	@Output() private create: EventEmitter<ProductModel> = new EventEmitter<ProductModel>();
	@Output() private upload: EventEmitter<File> = new EventEmitter<File>();
	@Output() private cancelEvent: EventEmitter<null> = new EventEmitter<null>();
	@ViewChild('productForm')
	public productForm: NgForm;

	constructor() {}

	ngOnInit() {}
	submitForm(form: NgForm) {
		if (form.valid && this.productModel.image_url && this.isEdit) {
			this.update.emit(this.productModel);
		} else if (form.valid && this.productModel.image_url && !this.isEdit) {
			this.create.emit(this.productModel);
		} else {
			alert('invalid data');
		}
	}
	changeFile(event) {
		this.file = event.target.files[0];
		this.uploadFile();
	}
	uploadFile() {
		if (this.file) {
			this.upload.emit(this.file);
		} else {
			alert('Please select file.');
		}
	}
	cancel(form: NgForm) {
		form.reset();
		this.cancelEvent.emit();
	}
	deleteProduct() {
		this.delete.emit(this.productModel.id);
	}
	private checkNegoParams(nego_params) {
		const newParams = [];
		for (const p of ['price', 'quantity', 'lead_time', 'payment_terms']) {
			let param = nego_params.find(pr => pr.name === p);
			if (!param) {
				param = {
					name: p,
					min: null,
					baseline: null,
					weight: null,
					inverse: false,
				};
			}
			newParams.push(param);
		}
		return newParams;
	}
}
