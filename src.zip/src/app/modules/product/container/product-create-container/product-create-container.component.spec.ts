import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ProductCreateContainerComponent } from './product-create-container.component';
import { SpinnerComponent } from 'src/app/shared/components/spinner/spinner.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ToastService } from 'src/app/shared/services/toast.service';

describe('ProductCreateContainerComponent', () => {
  let component: ProductCreateContainerComponent;
  let fixture: ComponentFixture<ProductCreateContainerComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductCreateContainerComponent,SpinnerComponent ],
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }],
      schemas: [NO_ERRORS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductCreateContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create product-create-content component', () => {
    expect(component).toBeTruthy();
  });
});
