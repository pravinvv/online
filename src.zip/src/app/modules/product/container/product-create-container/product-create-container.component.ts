import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastService } from 'src/app/shared/services/toast.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { ProductService } from '../../services/product.service';
import { ProductModel } from 'src/app/shared/models/product.model';
import { LoaderService } from 'src/app/shared/services/loader.service';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
	selector: 'app-product-create-container',
	templateUrl: './product-create-container.component.html',
	styleUrls: ['./product-create-container.component.css'],
})
export class ProductCreateContainerComponent implements OnInit {
	public productModel: ProductModel;
	public image_url: string;
	public loaderId = 'app-product-create';

	constructor(
		private router: Router,
		private activatedRoute: ActivatedRoute,
		private toast: ToastService,
		private modalService: ModalService,
		private productService: ProductService,
		private loaderService: LoaderService,
		private auth: AuthService
	) {}

	ngOnInit() {
		this.activatedRoute.params.subscribe(params => {
			if (params.id) {
				this.getSingleProduct(params.id);
			}
		});
	}
	createProduct(Product: ProductModel) {
		Product.organisation_id = this.auth.sessionUserInfo.Staff.Organisation.id;
		this.productService.createProduct(Product).subscribe((res: ProductModel) => {
			this.toast.showSuccess('Product information created.');
			this.router.navigate(['/secured/product/list']);
		});
	}
	upload(file: File) {
		this.productService.uploadProductImage(file).subscribe((res: any) => {
			this.toast.showSuccess('file uploaded successfully');
			this.image_url = res.image_url;
		});
	}
	updateProduct(Product: ProductModel) {
		this.productService.updateProduct(Product.id, Product).subscribe((res: ProductModel) => {
			this.toast.showSuccess('Product information updated.');
			this.router.navigate(['/secured/product/list']);
		});
	}
	deleteProduct() {
		const modalRef = this.modalService.open({ name: 'confirmation', param: this.productModel.name });
		modalRef.result.then(
			res => {				
				if (res === 'Ok') {
					this.productService.deleteProduct(this.productModel.id).subscribe((result: any) => {
						this.toast.showSuccess('Product information deleted.');
						this.router.navigate(['/secured/product/list']);
					});
				}
			},
			() => {}
		);
	}

	getSingleProduct(productId: number) {
		this.loaderService.startLoader(this.loaderId);
		this.productService.getSingleProduct(productId).subscribe((res: ProductModel) => {
			this.productModel = res;
			this.loaderService.stopLoader(this.loaderId);
		});
	}
	cancel() {
		this.router.navigate(['/secured/product/list']);
	}
}
