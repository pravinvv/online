import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';

import { ProductListContainerComponent } from './product-list-container.component';
import { ProductService } from '../../services/product.service';
import { ToastService } from 'src/app/shared/services/toast.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { SpinnerComponent } from 'src/app/shared/components/spinner/spinner.component';

describe('ProductListContainerComponent', () => {
  let component: ProductListContainerComponent;
  let fixture: ComponentFixture<ProductListContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [ProductListContainerComponent, SpinnerComponent],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [{ provide: ToastService, useValue: ToastService }
      ]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductListContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create Product-List Container component ', () => {
    expect(component).toBeTruthy();
  });

   


});
