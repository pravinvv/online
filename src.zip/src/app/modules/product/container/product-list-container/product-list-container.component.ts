import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/shared/services/loader.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { ToastService } from 'src/app/shared/services/toast.service';
import { ProductService } from '../../services/product.service';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
	selector: 'app-product-list-container',
	templateUrl: './product-list-container.component.html',
	styleUrls: ['./product-list-container.component.css'],
})
export class ProductListContainerComponent implements OnInit {
	public loaderId = 'app-product-list';
	public setting = {
		columns: {
			name: {
				title: 'Name',
				filter: true,
				addable: false,
			},
			available_quantity: {
				title: 'Available Stock',
				filter: true,
				addable: false,
			},
			description: {
				title: 'Description',
				filter: true,
				addable: false,
			},
		},
		actions: {
			add: false,
			edit: false,
			delete: false,
			custom: [
				{
					name: 'Edit',
					title: '<i class="ti-pencil text-info m-r-10"> ',
				},
			],
		},
	};
	public source: Array<any> = [];
	constructor(
		private router: Router,
		private loaderService: LoaderService,
		private modalService: ModalService,
		private productService: ProductService,
		private auth: AuthService
	) {}

	ngOnInit() {
		this.getProductList();
	}
	add() {
		this.router.navigate(['/secured/product/create']);
	}
	edit(id) {
		this.router.navigate(['/secured/product/edit', id]);
	}
	delete(id) {
		const modalRef = this.modalService.open({ name: 'confirmation', param: id });
		modalRef.result.then(res => {
			if (res === 'Ok') {
			}
		});
	}
	private getProductList() {
		this.loaderService.startLoader(this.loaderId);
		const orgId = this.auth.sessionUserInfo.Staff.Organisation.id;
		this.productService.getProductList(orgId).subscribe(
			result => {
				this.source = result;
				this.loaderService.stopLoader(this.loaderId);
			},
			err => {
				this.loaderService.stopLoader(this.loaderId);
			}
		);
	}
}
