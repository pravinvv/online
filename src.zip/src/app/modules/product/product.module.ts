import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { ProductListContainerComponent } from './container/product-list-container/product-list-container.component';
import { ProductCreateContainerComponent } from './container/product-create-container/product-create-container.component';
import { ProductFormComponent } from './components/product-form/product-form.component';
import { ProductRoutes } from './product.routing';

@NgModule({
	declarations: [ProductListContainerComponent, ProductCreateContainerComponent, ProductFormComponent],
	imports: [CommonModule, RouterModule.forChild(ProductRoutes), FormsModule, SharedModule],
})
export class ProductModule {}
