import { TestBed } from '@angular/core/testing';
import { ProductService } from './product.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ToastService } from 'src/app/shared/services/toast.service';
import * as getsingleproduct from '../../../../spec/mock/modules/product/service/get-single-product.json';
import * as getproductlist from '../../../../spec/mock/modules/product/service/get-product-list.json';
import * as updateproduct from '../../../../spec/mock/modules/product/service/update-product.json';
import * as createproduct from '../../../../spec/mock/modules/product/service/create-product.json';
import * as deleteproduct from '../../../../spec/mock/modules/product/service/delete-product.json';
import { environment } from '../../../../environments/environment';
import { inject } from '@angular/core/testing';

describe('ProductService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [{ provide: ToastService, useValue: ToastService }]

  }));

  beforeEach(() => {
    this.mockgetsingleproductwithid = getsingleproduct.id;
    this.mocksingleproductdata = getsingleproduct;
    this.mockgetproductlist = getproductlist;
    this.mockupdateproductid = updateproduct.id;
    this.mockupdatedataproduct = updateproduct;
    this.mockcreateproduct = createproduct;
    this.mockdeleteproductid = deleteproduct.id;
    this.mockdeleteproduct = deleteproduct;
  });

  it('should be created Product Service', () => {
    const service: ProductService = TestBed.get(ProductService);
    expect(service).toBeTruthy();
  });

  describe(' should call api to the single product api', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return the single product from product view', inject([HttpTestingController, ProductService, ToastService], (
      httpMock: HttpTestingController,
      service: ProductService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.getSingleProduct(this.mockgetsingleproductwithid).subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mocksingleproductdata);
      });
      // HTTP request mock
      const mockUrl = `${baseUrl}${environment.api.getSingleProduct}`;
      let url = mockUrl.replace('{id}', this.mockgetsingleproductwithid.toString());

      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('GET');
      req.flush(this.mocksingleproductdata);
      httpMock.verify();
    }));

  }); // getSingleProduct


  describe(' should call to getallProductList api', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return the getAll Api', inject([HttpTestingController, ProductService, ToastService], (
      httpMock: HttpTestingController,
      service: ProductService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.getProductList().subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockgetproductlist);
      });
      // HTTP request mock
      const mockUrl = `${baseUrl}${environment.api.listProduct}`;
      const req = httpMock.expectOne(mockUrl);
      expect(req.request.method).toEqual('GET');
      req.flush(this.mockgetproductlist);
      httpMock.verify();
    }));

  }); // getProductList

  describe('should call to update api', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return the  updated record of specific id', inject([HttpTestingController, ProductService, ToastService], (
      httpMock: HttpTestingController,
      service: ProductService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.updateProduct(this.mockupdateproductid, this.mockupdatedataproduct).subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockupdatedataproduct);
      });
      // HTTP request mock
      const mockUrl = `${baseUrl}${environment.api.updateProduct}`;
      let url = mockUrl.replace('{id}', this.mockupdateproductid.toString());
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('PUT');
      req.flush(this.mockupdatedataproduct);
      httpMock.verify();
    }));
  }); // Update Product

  describe('should call to post api in Products', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should create the Product', inject([HttpTestingController, ProductService, ToastService], (
      httpMock: HttpTestingController,
      service: ProductService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.createProduct(this.mockcreateproduct).subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockcreateproduct);
      });
      // HTTP request mock
      const mockUrl = `${baseUrl}${environment.api.createProduct}`;
      const req = httpMock.expectOne(mockUrl);
      expect(req.request.method).toEqual('POST');
      req.flush(this.mockcreateproduct);
      httpMock.verify();
    }));
  }); // Create  Product

  describe('should call to delete api', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return the  delete the record', inject([HttpTestingController, ProductService, ToastService], (
      httpMock: HttpTestingController,
      service: ProductService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.deleteProduct(this.mockdeleteproductid).subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockdeleteproduct);
      });
      // HTTP request mock
      const mockUrl = `${baseUrl}${environment.api.deleteProduct}`;
      let url = mockUrl.replace('{id}', this.mockdeleteproductid.toString());
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('DELETE');
      req.flush(this.mockdeleteproduct);
      httpMock.verify();
    }));
  }); // Delete Organisation


});
