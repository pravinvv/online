import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { ProductModel } from '../../../shared/models/product.model';
import { Observable, throwError } from 'rxjs';
import 'rxjs/add/operator/catch';
import { ToastService } from '../../../shared/services/toast.service';
@Injectable({
	providedIn: 'root',
})
export class ProductService {
	private baseUrl;

	constructor(private http: HttpClient, private toast: ToastService) {
		this.baseUrl = environment.SVC_ADMIN;
	}
	private error(err) {
		err = err || {};
		this.toast.showError(err.message);
		return err.message;
	}
	createProduct(org: ProductModel): Observable<ProductModel> {
		const url = `${this.baseUrl}${environment.api.createProduct}`;
		return this.http.post<ProductModel>(url, org).catch(err => throwError(this.error(err)));
	}
	uploadProductImage(file: File): Observable<HttpResponse<any>> {
		const url = `${this.baseUrl}${environment.api.uploadProductImage}`;
		const formData = new FormData();
		formData.set('file', file);

		return this.http.post<HttpResponse<any>>(url, formData).catch(err => throwError(this.error(err)));
	}

	updateProduct(productId: number, org: ProductModel): Observable<ProductModel> {
		let url = `${this.baseUrl}${environment.api.updateProduct}`;
		url = url.replace('{id}', productId.toString());
		return this.http.put<ProductModel>(url, org).catch(err => throwError(this.error(err)));
	}
	getProductList(organisation_id?): Observable<Array<ProductModel>> {
		let url = `${this.baseUrl}${environment.api.listProduct}`;
		if (organisation_id) {
			url = `${url}?organisation_id=${organisation_id}`;
		}
		return this.http.get<Array<ProductModel>>(url).catch(err => throwError(this.error(err)));
	}

	getSingleProduct(productId: number): Observable<ProductModel> {
		let url = `${this.baseUrl}${environment.api.getSingleProduct}`;
		url = url.replace('{id}', productId.toString());

		return this.http.get<ProductModel>(url).catch(err => throwError(this.error(err)));
	}
	deleteProduct(productId: number): Observable<HttpResponse<any>> {
		let url = `${this.baseUrl}${environment.api.deleteProduct}`;
		url = url.replace('{id}', productId.toString());

		return this.http.delete<HttpResponse<any>>(url).catch(err => throwError(this.error(err)));
	}
}
