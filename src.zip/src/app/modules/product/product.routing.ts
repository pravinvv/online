import { Routes } from '@angular/router';
import { ProductCreateContainerComponent } from './container/product-create-container/product-create-container.component';
import { ProductListContainerComponent } from './container/product-list-container/product-list-container.component';

export const ProductRoutes: Routes = [
	{
		path: '',
		children: [
			{
				path: 'create',
				component: ProductCreateContainerComponent,
				data: {
					title: 'Create',
					urls: [{ title: 'Add Product', url: 'product/create' }, { title: 'Add Product' }],
				},
			},
			{
				path: 'edit/:id',
				component: ProductCreateContainerComponent,
				data: {
					title: 'Edit',
					urls: [{ title: 'Edit Product', url: 'product/edit/:id' }, { title: 'Edit Product' }],
				},
			},
			{
				path: 'list',
				component: ProductListContainerComponent,
				data: {
					title: 'List',
					urls: [
						{ title: 'Product List', url: 'product/list' },
						{ title: 'Product List' },
					],
				},
			},
		],
	},
];
