import { Component } from '@angular/core';
import { RegisterModel } from 'src/app/shared/models/user.model';
import { AuthService } from 'src/app/core/services/auth.service';
import { Router } from '@angular/router';

@Component({
	selector: 'app-signup',
	templateUrl: './signup.component.html',
})
export class SignupComponent {
	public registerModel: RegisterModel = {
		first_name: '',
		last_name: '',
		email: '',
		password: '',
		confirm_password: '',
		tnc: false,
	};
	errorDefined = false;
	sucessDefined = false;
	successAndErrorMsg: any;
	constructor(private auth: AuthService, private router: Router) {}

	doRegister() {
		this.auth.doRegister(this.registerModel).subscribe(
			response => {
				this.router.navigate(['/login']);
			},
			error => {
				this.errorDefined = true;
				this.successAndErrorMsg = error.message;
			}
		);
	}
}
