import { async, ComponentFixture, TestBed, inject, fakeAsync, tick } from '@angular/core/testing';
import { CommonModule, Location } from '@angular/common';
import { FormsModule, ReactiveFormsModule, NgForm } from '@angular/forms';
import { NgbModalModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AuthService } from '../../../core/services/auth.service';
import { environment } from '../../../../environments/environment';
import { LoginComponent } from './login.component';
import { By } from '@angular/platform-browser';
import { of } from 'rxjs';
import { Routes, Router } from '@angular/router';
import { ToastService } from '../../../shared/services/toast.service';
const routes: Routes = [
    { path: 'secured/dashboard', component: LoginComponent },
];
describe('LoginComponent', () => {
    let component: LoginComponent;
    let fixture: ComponentFixture<LoginComponent>;
    let datAsService;
    let router: Router;
    let location: Location;
    //   const loginInputMock: any = loginInput;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                RouterTestingModule.withRoutes(routes),
                CommonModule,
                NgbModule,
                NgbModalModule,
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [LoginComponent],
            providers: [
                AuthService,
                { provide: ToastService, useValue: ToastService }
            ],
        }).compileComponents();
    }));
    beforeEach(() => {
        // trigger current navigation
        router = TestBed.get(Router);
        location = TestBed.get(Location);
        fixture = TestBed.createComponent(LoginComponent);
        router.initialNavigation();
        fixture.detectChanges();
        component = fixture.componentInstance;
        datAsService = fixture.debugElement.injector.get(AuthService);
    });
    it('should create', () => {
        expect(fixture).toBeDefined();
        expect(component).toBeTruthy();
    });
    describe('Forgot Password', () => {
        it('open form click on forgot password and back login form', () => {
            component.showRecoverForm();
            expect(component.recoverform).toBeTruthy();
            fixture.detectChanges();
            component.showRecoverForm();
            expect(component.recoverform).toBeFalsy();
        });
    });
    it('should call doLogin', () => {
        component.loginModel.username = 'parvej28@gmail.com';
        component.loginModel.password = '12345678';
        component.doLogin();
        spyOn(datAsService, 'doLogin').and.callThrough();
    });
});
