import { Component } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { UserService } from 'src/app/core/services/user.service';
import { Router } from '@angular/router';
import { LoginModel } from 'src/app/shared/models/user.model';
import { LoaderService } from 'src/app/shared/services/loader.service';
import { mergeMap } from 'rxjs/operators';

@Component({
	selector: 'app-login',
	templateUrl: './login.component.html',
})
export class LoginComponent {
	public loginModel: LoginModel = { username: '', password: '', remember_me: false };
	constructor(
		private auth: AuthService,
		private router: Router,
		private loaderService: LoaderService,
		private userService: UserService
	) {}

	loginform = true;
	recoverform = false;
	error: any;
	showRecoverForm() {
		this.loginform = !this.loginform;
		this.recoverform = !this.recoverform;
	}
	doLogin() {
		this.loaderService.startLoader('master');
		this.auth.isAuthenticated = true;

		this.auth
			.doLogin(this.loginModel)
			.pipe(mergeMap(l => this.userService.getUserInfo()))
			.subscribe(
				data => {
					this.router.navigate(['/secured/dashboard']);
					this.loaderService.stopLoader('master');
				},
				error => {
					this.error = error.message;
					this.loaderService.stopLoader('master');
				}
			);
	}
}
