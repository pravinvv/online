import { Routes } from '@angular/router';

import { NotfoundComponent } from './404/not-found.component';
import { LockComponent } from './lock/lock.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { AuthGuard } from 'src/app/core/guards/auth.guard';

export const AuthenticationRoutes: Routes = [
	{
		path: '',
		children: [
			{
				path: '404',
				component: NotfoundComponent,
			},
			{
				path: 'lock',
				component: LockComponent,
				// canActivate: [AuthGuard],
			},
			{
				path: 'login',
				component: LoginComponent,
				//canActivate: [AuthGuard],
			},
			{
				path: 'signup',
				component: SignupComponent,
				//canActivate: [AuthGuard],
			},
			{ path: '', redirectTo: '/login', pathMatch: 'full' },
		],
	},
];
