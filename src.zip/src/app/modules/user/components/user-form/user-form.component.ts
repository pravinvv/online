import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { UserInfoModel } from 'src/app/shared/models/user.model';
import { NgForm } from '@angular/forms';

@Component({
	selector: 'app-user-form',
	templateUrl: './user-form.component.html',
	styleUrls: ['./user-form.component.css'],
})
export class UserFormComponent implements OnInit {
	// public fullName;
	public isEdit = true;
	@Input('userInfoModel') private set user(data: UserInfoModel) {
		if (data) {
			this.userInfoModel = data;
			// this.fullName = this.userInfoModel.first_name + '' + this.userInfoModel.first_name;
			this.isEdit = true;
		} else {
			this.isEdit = false;
		}
	}
	@Output() private delete: EventEmitter<number> = new EventEmitter<number>();
	@Output() private update: EventEmitter<UserInfoModel> = new EventEmitter<UserInfoModel>();
	@Output() private create: EventEmitter<UserInfoModel> = new EventEmitter<UserInfoModel>();
	@Output() private cancelEvent: EventEmitter<null> = new EventEmitter<null>();

	public userInfoModel: UserInfoModel = {
		id: null,
		first_name: '',
		last_name: '',
		email: '',
		status: 'active',
		phone_number: '',
		password: '',
		type: 'agent',
	};
	@ViewChild('userForm')
	public userForm: NgForm;
	constructor() {}
	ngOnInit() {}
	submitForm(form: NgForm) {
		if (form.valid && this.isEdit) {
			this.update.emit(this.userInfoModel);
		}
		if (form.valid && !this.isEdit) {
			this.create.emit(this.userInfoModel);
		}
	}

	cancel(form: NgForm) {
		form.reset();
		this.cancelEvent.emit();
	}
	deleteUser() {
		this.delete.emit(this.userInfoModel.id);
	}
}
