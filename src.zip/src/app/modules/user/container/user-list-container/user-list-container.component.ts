import { Component, OnInit } from '@angular/core';
import { UserInfoModel } from 'src/app/shared/models/user.model';
import { Router } from '@angular/router';
import { LoaderService } from '../../../../shared/services/loader.service';
import { UserService } from 'src/app/core/services/user.service';
import { AuthService } from '../../../../core/services/auth.service';
import { ModalService } from 'src/app/shared/services/modal.service';

@Component({
	selector: 'app-user-list-container',
	templateUrl: './user-list-container.component.html',
	styleUrls: ['./user-list-container.component.css'],
})
export class UserListContainerComponent implements OnInit {
	public loaderId = 'app-user-list';

	public setting = {
		columns: {
			name: {
				title: 'Name',
				addable: false,
				filter: {
					config: {
						inputClass: 'column-filter-1',
					},
				},
			},

			phone_number: {
				title: 'Mobile',
				addable: false,
				filter: {
					config: {
						inputClass: 'column-filter-3',
					},
				},
			},
			email: {
				title: 'Email',
				addable: false,
				filter: {
					config: {
						inputClass: 'column-filter-3',
					},
				},
			},
			status: {
				title: 'Status',
				addable: false,
				filter: {
					config: {
						inputClass: 'column-filter-2',
					},
				},
			},
			type: {
				title: 'Type',
				addable: false,
				filter: {
					config: {
						inputClass: 'column-filter-2',
					},
				},
			},
		},
		filter: {
			inputClass: 'column-filter-1',
		},
		actions: {
			add: false,
			edit: false,
			delete: false,
			custom: [
				{
					name: 'Edit',
					title: '<i class="ti-pencil text-info m-r-10"> ',
				},
			],
		},
	};

	public source: Array<UserInfoModel> = [];
	constructor(
		private router: Router,
		private userService: UserService,
		private loaderService: LoaderService,
		private modalService: ModalService
	) {}

	ngOnInit() {
		this.getUser();
	}
	add() {
		this.router.navigate(['/secured/user/create']);
	}
	edit(id) {
		this.router.navigate(['/secured/user/edit', id]);
	}
	delete(id) {
		const modalRef = this.modalService.open({ name: 'confirmation', param: id });
		modalRef.result.then(res => {
			if (res === 'Ok') {
			}
		});
	}

	getUser() {
		this.loaderService.startLoader(this.loaderId);
		this.userService.getUserList().subscribe(
			(res: any) => {
				this.source = res;
				this.loaderService.stopLoader(this.loaderId);
			},
			err => {
				this.loaderService.stopLoader(this.loaderId);
			}
		);
	}
}
