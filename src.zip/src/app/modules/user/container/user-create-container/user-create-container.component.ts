import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoaderService } from 'src/app/shared/services/loader.service';
import { ToastService } from '../../../../shared/services/toast.service';
import { ModalService } from '../../../../shared/services/modal.service';
import { UserService } from '../../../../core/services/user.service';
import { UserInfoModel } from 'src/app/shared/models/user.model';
import { AuthService } from '../../../../core/services/auth.service';

@Component({
	selector: 'app-user-create-container',
	templateUrl: './user-create-container.component.html',
	styleUrls: ['./user-create-container.component.css'],
})
export class UserCreateContainerComponent implements OnInit {
	public userInfoModel: UserInfoModel;
	public loaderId = 'app-user-create';
	constructor(
		private router: Router,
		private loaderService: LoaderService,
		private toast: ToastService,
		private activatedRoute: ActivatedRoute,
		private modalService: ModalService,
		private userService: UserService,
		private authService: AuthService
	) {}

	ngOnInit() {
		this.activatedRoute.params.subscribe(params => {
			if (params.id) {
				this.getSingleUser(params.id);
			}
		});
	}

	addUser(User: UserInfoModel) {
		this.userService.createUser(User).subscribe((res: UserInfoModel) => {
			this.toast.showSuccess('User Created Successfully');
			this.router.navigate(['/secured/user/list']);
		});
	}

	getSingleUser(userId: number) {
		this.loaderService.startLoader(this.loaderId);
		this.userService.getSingleUser(userId).subscribe((res: UserInfoModel) => {
			this.userInfoModel = res;
			this.loaderService.stopLoader(this.loaderId);
		});
	}
	cancel() {
		this.router.navigate(['/secured/user/list']);
	}
	updateUser(User: UserInfoModel) {
		this.userService.updateUser(User.id, User).subscribe((res: UserInfoModel) => {
			this.toast.showSuccess('User Information updated Succesfully');
			this.router.navigate(['/secured/user/list']);
		});
	}

	deleteUser(userId: number) {
		const modalRef = this.modalService.open({ name: 'confirmation', param: this.userInfoModel.first_name });
		modalRef.result.then(
			res => {
				if (res === 'Ok') {
					this.userService.deleteUser(userId).subscribe((result: any) => {
						this.toast.showSuccess('User information deleted.');
						this.router.navigate(['/secured/user/list']);
					});
				}
			},
			() => {}
		);
	}
}
