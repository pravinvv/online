import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserFormComponent } from '../user/components/user-form/user-form.component';
import { UserCreateContainerComponent } from './container/user-create-container/user-create-container.component';
import { UserListContainerComponent } from './container/user-list-container/user-list-container.component';
import { RouterModule } from '@angular/router';
import { UserRoutes } from './user.routing';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';

@NgModule({
  declarations: [UserFormComponent, UserCreateContainerComponent, UserListContainerComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(UserRoutes),
    FormsModule,
    SharedModule
  ]
})
export class UserModule { }
