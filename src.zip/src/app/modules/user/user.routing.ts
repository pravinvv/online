import { Routes } from '@angular/router';
import { UserCreateContainerComponent } from './container/user-create-container/user-create-container.component';
import { UserListContainerComponent } from './container/user-list-container/user-list-container.component';

export const UserRoutes: Routes = [
	{
		path: '',
		children: [
			{
				path: 'create',
				component: UserCreateContainerComponent,
				data: {
					title: 'Create',
					urls: [{ title: 'Add User', url: 'user/create' }, { title: 'Add User' }],
				},
			},
			{
				path: 'edit/:id',
				component:  UserCreateContainerComponent,
				data: {
					title: 'Edit',
					urls: [{ title: 'Edit User', url: 'user/edit/:id' }, { title: 'Edit User' }],
				},
			},
			{
				path: 'list',
				component: UserListContainerComponent,
				data: {
					title: 'List',
					urls: [
						{ title: 'User List', url: 'user/list' },
						{ title: 'User List' },
					],
				},
			},
		],
	},
];
