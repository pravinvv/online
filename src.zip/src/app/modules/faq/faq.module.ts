import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SkillListContainerComponent } from './containers/skill-list-container/skill-list-container.component';
import { RouterModule } from '@angular/router';
import { FAQRoutes } from './faq.routing';
import { CreateIntentContainerComponent } from './containers/create-intent-container/create-intent-container.component';
import { QnaFormComponent } from './components/qna-form/qna-form.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
	declarations: [SkillListContainerComponent, CreateIntentContainerComponent, QnaFormComponent],
	imports: [CommonModule, RouterModule.forChild(FAQRoutes), FormsModule, SharedModule],
})
export class FaqModule {}
