import { Routes } from '@angular/router';
import { SkillListContainerComponent } from './containers/skill-list-container/skill-list-container.component';
import { CreateIntentContainerComponent } from './containers/create-intent-container/create-intent-container.component';



export const FAQRoutes: Routes = [
	{
		path: '',
		children: [
			{
				path: 'create',
				component: CreateIntentContainerComponent,
				data: {
					title: 'Create',
					urls: [{ title: 'Add Intent', url: 'faq/create' }, { title: 'Add Intent' }],
				},
			},
			{
				path: 'edit/:id',
				component: CreateIntentContainerComponent,
				data: {
					title: 'Edit',
					urls: [{ title: 'Edit Intent', url: 'faq/edit/:id' }, { title: 'Edit Intent' }],
				},
			},
			{
				path: 'list',
				component: SkillListContainerComponent,
				data: {
					title: 'List',
					urls: [{ title: 'List Questions and Answers', url: 'faq/list' }, { title: 'List Question And Answers' }],
				},
			},

		],
	},
];
