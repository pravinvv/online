import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { QnaFormComponent } from './qna-form.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';

describe('QnaFormComponent', () => {
  let component: QnaFormComponent;
  let fixture: ComponentFixture<QnaFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [QnaFormComponent],
      imports: [ReactiveFormsModule, FormsModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QnaFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create qna-form-component', () => {
    expect(component).toBeTruthy();
  });

  it('should Able to see category field in faq  Edit view', () => {
    let de = fixture.debugElement.query(By.css('#intent'));
    expect(de).toBeTruthy();
  });

  it('should Able to see Description field in faq Edit view', () => {
    let de = fixture.debugElement.query(By.css('#description'))
    expect(de).toBeTruthy();
  });


  it('should Able to see Answer field in faq Edit view', () => {
    let de = fixture.debugElement.query(By.css('#answer'));
    expect(de).toBeTruthy();
  });

  it('should Able to see Question field in faq Edit view', () => {
    let de = fixture.debugElement.query(By.css('#question'));
    expect(de).toBeTruthy();
  });

  it('should Able to see   Add Button  in faq Edit view', () => {
    let de = fixture.debugElement.query(By.css('#addQuestion'));
    expect(de).toBeTruthy();
  });

  it('should be  Able to change intent in the faq view. ', () => {
    const intent = 'GEN-001-Start_Conversation';
    fixture.whenStable().then(() => {
      const dataEle = component.basicForm.controls['intent'];
      dataEle.setValue(intent);
      expect(dataEle.value).toEqual(intent);
    });
  });

  it('should be  Able to change description in the faq view. ', () => {
    const description = 'Get a help from agent1.';
    fixture.whenStable().then(() => {
      const dataEle = component.basicForm.controls['description'];
      dataEle.setValue(description);
      expect(dataEle.value).toEqual(description);
    });
  });

  it('should be  Able to change answer in the faq view. ', () => {
    const answer = 'We believe in giving a fair and fast opportunity to any authentic entrepreneur.';
    fixture.whenStable().then(() => {
      const dataEle = component.basicForm.controls['answer'];
      dataEle.setValue(answer);
      expect(dataEle.value).toEqual(answer);
    });
  });

  it('should be  Able to add question in the faq view. ', () => {
    const question = 'We believe in our work?.';
    fixture.whenStable().then(() => {
      const dataEle = component.basicForm.controls['question'];
      fixture.detectChanges();
      dataEle.setValue(question);
      expect(dataEle.value).toEqual(question);
    });
  });

  it('should be able to cancel in product view', async(() => {
    spyOn(component, 'addQuestion');
    component.qnaModel.question = true;
    fixture.detectChanges();
    const button = fixture.debugElement.nativeElement.querySelector('button');
    button.click();
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.addQuestion).toHaveBeenCalled();
    });
  }));





});
