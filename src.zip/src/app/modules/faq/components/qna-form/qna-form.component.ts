import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
	selector: 'app-qna-form',
	templateUrl: './qna-form.component.html',
	styleUrls: ['./qna-form.component.css'],
})
export class QnaFormComponent implements OnInit {
	public qnaModel: any = {};
	public isIntentEdit = false;
	public isDialogEdit = false;

	@Input('model') set inputModel(model) {
		if (model && model.hasOwnProperty('intent')) {
			this.qnaModel = model;
			this.qnaModel.old_intent = model.intent;
			this.isIntentEdit = model.intent ? true : false;
			this.isDialogEdit = model.dialogNode.dialog_node ? true : false;
			model.dialogNode.old_dialog_node = model.dialogNode.dialog_node;

			model.dialogNode.hasOwnProperty('output') &&
			model.dialogNode.output.hasOwnProperty('generic') &&
			model.dialogNode.output.generic[0].values[0]
				? (this.qnaModel.answer = model.dialogNode.output.generic[0].values[0].text)
				: (this.qnaModel.answer = '');
		}
	}

	@Output() event: EventEmitter<any> = new EventEmitter<any>();
	@ViewChild('basicForm')
	public basicForm: NgForm;


	constructor() {}

	ngOnInit() {}

	intentAction() {
		const { intent, old_intent, description } = this.qnaModel;
		if (!intent || !description) {
			return;
		}

		if (this.isIntentEdit) {
			this.event.emit({ intent, old_intent, description, operation: 'updateIntent' });
		} else {
			this.event.emit({ intent, description, operation: 'createIntent' });
		}
	}

	dialogNodeAction() {
		if (!this.qnaModel.answer && !this.qnaModel.intent) {
			return;
		}

		if (this.isDialogEdit) {
			// tslint:disable-next-line:prefer-const
			let { dialog_node, old_dialog_node, description, conditions, output, title } = this.qnaModel.dialogNode;
			if (!output.hasOwnProperty('generic')) {
				output = {
					generic: [
						{
							values: [{ text: this.qnaModel.answer }],
							response_type: 'text',
							selection_policy: 'sequential',
						},
					],
				};
			} else {
				output.generic[0].values[0].text = this.qnaModel.answer;
			}
			this.event.emit({
				dialog_node,
				old_dialog_node,
				conditions,
				output,
				description,
				title,
				operation: 'updateDialogNode',
			});
		} else {
			const output = {
				generic: [
					{ values: [{ text: this.qnaModel.answer }], response_type: 'text', selection_policy: 'sequential' },
				],
			};
			this.event.emit({
				conditions: `#${this.qnaModel.intent}`,
				title: `#${this.qnaModel.intent}`,
				dialog_node: this.qnaModel.intent,
				output,
				description: this.qnaModel.description,
				operation: 'createDialogNode',
			});
		}
	}
	addQuestion() {
		const { intent } = this.qnaModel;

		if (!this.qnaModel.question && !intent) {
			return;
		}
		this.event.emit({ intent, text: this.qnaModel.question, operation: 'createUserExample' });
		this.qnaModel.question = null;
	}
	updateExample(example) {
		const { text, old_text } = example;
		if (!text) {
			return;
		}
		this.event.emit({
			text,
			old_text,
			intent: this.qnaModel.intent,
			operation: 'updateUserExample',
		});
	}
	deleteExample(example) {
		const { text } = example;
		if (!text) {
			return;
		}
		this.event.emit({
			text,
			intent: this.qnaModel.intent,
			operation: 'deleteUserExample',
		});
	}
}
