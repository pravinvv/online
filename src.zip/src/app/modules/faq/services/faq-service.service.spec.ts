import { TestBed, inject } from '@angular/core/testing';
import { FaqServiceService } from './faq-service.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ToastService } from 'src/app/shared/services/toast.service';
import * as getintentlist from '../../../../spec/mock/modules/faq/service/get-intent-list.json';
import * as getsingleorganisation from '../../../../spec/mock/modules/organisation/service/get-single-organisation.json';
import * as getsingleintent from '../../../../spec/mock/modules/faq/service/get-intent-list.json';
import * as createintent from '../../../../spec/mock/modules/faq/service/create-intent.json';
import * as updateintent from '../../../../spec/mock/modules/faq/service/update-intent.json';
import * as deleteintent from '../../../../spec/mock/modules/faq/service/delete-intent.json';
import * as getexamplelist from '../../../../spec/mock/modules/faq/service/get-exampleList.json';
import * as createexample from '../../../../spec/mock/modules/faq/service/create-example.json';
import * as getsingleexample from '../../../../spec/mock/modules/faq/service/get-single-example.json';
import * as updateexample from '../../../../spec/mock/modules/faq/service/update-example.json';
import * as deleteexample from '../../../../spec/mock/modules/faq/service/update-example.json';
import * as getdialognodeList from '../../../../spec/mock/modules/faq/service/get-dialog-nodeList.json';
import * as updatedialognode from '../../../../spec/mock/modules/faq/service/update-dialog-node.json';
import * as createdialognode from '../../../../spec/mock/modules/faq/service/create-dialog-node.json';
import { environment } from '../../../../environments/environment';

describe('FaqServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [{ provide: ToastService, useValue: ToastService }]
  }));
  beforeEach(() => {
    this.mockgetintentlist = getintentlist;
    this.mockgetsingleorganisationwithworkspace_id = getsingleorganisation.workspace_id;
    this.mockgetsingleintent = getsingleintent;
    this.mockgetsingleintentid = this.mockgetsingleintent.intent;
    this.mockcreateintent = createintent;
    this.mockupdateintent = updateintent;
    this.mockdeleteintent = deleteintent;
    this.mockexampleList = getexamplelist;
    this.createexample = createexample;
    this.createexamplewithid = createexample.text;
    this.mockgetsingleexample = getsingleexample;
    this.mockupdateexample = updateexample;
    this.mockdeleteexample = deleteexample;
    this.mockgetdialognodeList = getdialognodeList;
    this.mockupdatedialognode = updatedialognode;
    this.mockcreatedialognode = createdialognode;
  });
  it('should be created faq Service', () => {
    const service: FaqServiceService = TestBed.get(FaqServiceService);
    expect(service).toBeTruthy();
  });
  describe(' should call to getallIntentList api', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));
    it('should return the getAll list', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.getIntentList(this.mockgetsingleorganisationwithworkspace_id).subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockgetintentlist);
      });
      // HTTP request mock
      const mockUrl = `${baseUrl}${environment.api.listIntent}`;
      let url = mockUrl.toString().replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString());
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('GET');
      req.flush(this.mockgetintentlist);
      httpMock.verify();
    }));
  }); // getIntentList

  describe(' should call to createintentlist api', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return the createintentlist Api', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.createIntent(this.mockgetsingleorganisationwithworkspace_id, this.mockcreateintent).subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockcreateintent);
      });
      // HTTP request mock
      const mockUrl = `${baseUrl}${environment.api.createIntent}`;
      let url = mockUrl.replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString());
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('POST');
      req.flush(this.mockcreateintent);
      httpMock.verify();
    }));
  }); // createIntent

  describe(' should call to singleIntentList api', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));
    it('should return getSungleIntentList Api', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.getSingleIntent(this.mockgetsingleorganisationwithworkspace_id, 'NEG-01_SelectProduct').subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockgetsingleintent);
      });
      // HTTP request mock
      let url = `${baseUrl}${environment.api.getSingleIntent}`;
      url = url.replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString()).replace('{intent_id}', 'NEG-01_SelectProduct');
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('GET');
      req.flush(this.mockgetsingleintent);
      httpMock.verify();
    }));
  }); // getSingleIntentList

  describe(' should call to UpdateIntentList', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return the updateIntent Api', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      let intentId: any = 'NEG-01_SelectProduct';
      service.updateIntent(this.mockgetsingleorganisationwithworkspace_id, 'NEG-01_SelectProduct', this.mockcreateintent).subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockupdateintent);
      });
      // HTTP request mock
      let url = `${baseUrl}${environment.api.updateIntent}`;
      url = url.replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString()).replace('{intent_id}', 'NEG-01_SelectProduct');
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('PUT');
      req.flush(this.mockupdateintent);
      httpMock.verify();
    }));
  }); // UpdateIntent

  describe(' should call to DeleteIntentApi', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return the deleteintent Api', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.deleteIntent(this.mockgetsingleorganisationwithworkspace_id, 'NEG-01_SelectProduct').subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockdeleteintent);
      });
      // HTTP request mock
      let url = `${baseUrl}${environment.api.deleteIntent}`;
      url = url.replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString()).replace('{intent_id}', 'NEG-01_SelectProduct');
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('DELETE');
      req.flush(this.mockdeleteintent);
      httpMock.verify();
    }));
  }); // DeleteIntent

  describe(' should call to getExampleListApi', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return getExampleList', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.getExampleList(this.mockgetsingleorganisationwithworkspace_id, 'NEG-01_SelectProduct').subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockexampleList);
      });
      // HTTP request mock
      let url = `${baseUrl}${environment.api.getExampleList}`;
      url = url.replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString()).replace('{intent_id}', 'NEG-01_SelectProduct');
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('GET');
      req.flush(this.mockexampleList);
      httpMock.verify();
    }));
  }); // getExampleList

  describe(' should call to createExample api', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));
    it('should return the createExample Api', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.createExample(this.mockgetsingleorganisationwithworkspace_id, 'NEG-01_SelectProduct', this.createexample).subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.createexample);
      });
      // HTTP request mock
      let url = `${baseUrl}${environment.api.createExample}`;
      url = url.replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString()).replace('{intent_id}', 'NEG-01_SelectProduct');
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('POST');
      req.flush(this.createexample);
      httpMock.verify();
    }));
  }); // createExample

  describe(' should call to getSingleExample api', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return the getSingleExample Api', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.getSingleExample(this.mockgetsingleorganisationwithworkspace_id, 'NEG-01_SelectProduct', 'Thanks').subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockgetsingleexample);
      });
      // HTTP request mock
      let url = `${baseUrl}${environment.api.getSingleExample}`;
      url = url
        .replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString())
        .replace('{intent_id}', 'NEG-01_SelectProduct')
        .replace('{example_id}', 'Thanks');
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('GET');
      req.flush(this.mockgetsingleexample);
      httpMock.verify();
    }));
  }); // getSingleExample

  describe(' should call to UpdateExample api', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return the UpdateExample Api', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.updateExample(this.mockgetsingleorganisationwithworkspace_id, 'NEG-01_SelectProduct', 'hey', this.mockupdateexample).subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockupdateexample);
      });
      // HTTP request mock
      let url = `${baseUrl}${environment.api.updateExample}`;
      url = url
        .replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString())
        .replace('{intent_id}', 'NEG-01_SelectProduct')
        .replace('{example_id}', 'hey');

      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('PUT');
      req.flush(this.mockupdateexample);
      httpMock.verify();
    }));
  }); // updateExample

  describe(' should call to deleteExample api', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return the DeleteExample Api', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.deleteExample(this.mockgetsingleorganisationwithworkspace_id, 'NEG-01_SelectProduct', 'Thanks').subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockdeleteexample);
      });
      // HTTP request mock

      let url = `${baseUrl}${environment.api.deleteExample}`;
      url = url
        .replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString())
        .replace('{intent_id}', 'NEG-01_SelectProduct')
        .replace('{example_id}', 'Thanks');
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('DELETE');
      req.flush(this.mockdeleteexample);
      httpMock.verify();
    }));
  }); // deleteExample

  describe(' should call to getDialogNodeListApi', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return getDialogNodeList', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.getDialogNodeList(this.mockgetsingleorganisationwithworkspace_id).subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockgetdialognodeList);
      });
      // HTTP request mock
      let url = `${baseUrl}${environment.api.listDialogNode}`;
      url = url.replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString());
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('GET');
      req.flush(this.mockgetdialognodeList);
      httpMock.verify();
    }));
  }); // getDialogNodeList

  describe(' should call to UpdateDialogNode List', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return the Update DialogNode', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.updateDialogNode(this.mockgetsingleorganisationwithworkspace_id, '#GEN-001-Start_Conversation', this.mockupdatedialognode).subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockupdatedialognode);
      });
      // HTTP request mock

      let url = `${baseUrl}${environment.api.updateDialogNode}`;
      url = url.replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString()).replace('{dialog_node_id}', '#GEN-001-Start_Conversation');
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('PUT');
      req.flush(this.mockupdatedialognode);
      httpMock.verify();
    }));
  }); // updateDialogNodeList

  describe(' should call tocreateNodeList', () => {
    beforeEach(() => TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }]
    }));

    it('should return the  CreateDialogNode', inject([HttpTestingController, FaqServiceService, ToastService], (
      httpMock: HttpTestingController,
      service: FaqServiceService, ) => {
      let baseUrl = environment.SVC_ADMIN;
      // Make an HTTP request
      service.createDialogNode(this.mockgetsingleorganisationwithworkspace_id, this.mockcreatedialognode).subscribe(response => {
        // When observable resolves, result should match test data
        expect(response).toEqual(this.mockcreatedialognode);
      });
      // HTTP request mock
      let url = `${baseUrl}${environment.api.createDialogNode}`;
      url = url.replace('{workspace_id}', this.mockgetsingleorganisationwithworkspace_id.toString());
      const req = httpMock.expectOne(url);
      expect(req.request.method).toEqual('POST');
      req.flush(this.mockcreatedialognode);
      httpMock.verify();
    }));
  }); //createDialogNodeList

});
