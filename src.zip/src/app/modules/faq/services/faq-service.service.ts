import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { Observable, throwError } from 'rxjs';
import 'rxjs/add/operator/catch';
import { ToastService } from '../../../shared/services/toast.service';
import { WorkspaceModel } from '../../../shared/models/workspace.model';
import { IntentModel } from 'src/app/shared/models/intent.model';
import { DialogNodeModel } from 'src/app/shared/models/dialog_node.model';
import { UserExample } from 'src/app/shared/models/user_example.model';

@Injectable({
	providedIn: 'root',
})
export class FaqServiceService {
	private baseUrl;
	constructor(private http: HttpClient, private toast: ToastService) {
		this.baseUrl = environment.SVC_ADMIN;
	}
	private error(err) {
		err = err.error || err || {};
		this.toast.showError(err.message);
		return err.message;
	}

	// =============== Workspace===============================================================//
	createWorkspace(body: WorkspaceModel): Observable<WorkspaceModel> {
		const url = `${this.baseUrl}${environment.api.createWorkspace}`;
		return this.http.post<WorkspaceModel>(url, body).catch(err => throwError(this.error(err)));
	}

	updateWorkspace(id: string, body: WorkspaceModel): Observable<WorkspaceModel> {
		let url = `${this.baseUrl}${environment.api.updateWorkspace}`;
		url = url.replace('{id}', id.toString());
		return this.http.put<WorkspaceModel>(url, body).catch(err => throwError(this.error(err)));
	}
	getWorkspaceList(): Observable<Array<WorkspaceModel>> {
		const url = `${this.baseUrl}${environment.api.listWorkspace}`;
		return this.http.get<Array<WorkspaceModel>>(url).catch(err => throwError(this.error(err)));
	}

	getSingleWorkspace(id: string): Observable<WorkspaceModel> {
		let url = `${this.baseUrl}${environment.api.getSingleWorkspace}`;
		url = url.replace('{id}', id.toString());

		return this.http.get<WorkspaceModel>(url).catch(err => throwError(this.error(err)));
	}
	deleteWorkspace(id: string): Observable<HttpResponse<any>> {
		let url = `${this.baseUrl}${environment.api.deleteWorkspace}`;
		url = url.replace('{id}', id.toString());
		return this.http.delete<HttpResponse<any>>(url).catch(err => throwError(this.error(err)));
	}

	// =============== Intents ===============================================================//
	createIntent(workspace_id: string, body: IntentModel): Observable<IntentModel> {
		let url = `${this.baseUrl}${environment.api.createIntent}`;
		url = url.replace('{workspace_id}', workspace_id.toString());
		return this.http.post<IntentModel>(url, body).catch(err => throwError(this.error(err)));
	}

	updateIntent(workspace_id: string, intent_id: string, body: IntentModel): Observable<IntentModel> {
		let url = `${this.baseUrl}${environment.api.updateIntent}`;
		url = url.replace('{workspace_id}', workspace_id.toString()).replace('{intent_id}', intent_id);
		return this.http.put<IntentModel>(url, body).catch(err => throwError(this.error(err)));
	}
	getIntentList(workspace_id: string): Observable<Array<IntentModel>> {
		let url = `${this.baseUrl}${environment.api.listIntent}`;
		url = url.toString().replace('{workspace_id}', workspace_id.toString());
		return this.http.get<Array<IntentModel>>(url).catch(err => throwError(this.error(err)));
	}

	getSingleIntent(workspace_id: string, intent_id: string): Observable<IntentModel> {
		let url = `${this.baseUrl}${environment.api.getSingleIntent}`;
		url = url.replace('{workspace_id}', workspace_id.toString()).replace('{intent_id}', intent_id);
		return this.http.get<IntentModel>(url).catch(err => throwError(this.error(err)));
	}
	deleteIntent(workspace_id: string, intent_id: string): Observable<HttpResponse<any>> {
		let url = `${this.baseUrl}${environment.api.deleteIntent}`;
		url = url.replace('{workspace_id}', workspace_id.toString()).replace('{intent_id}', intent_id);
		return this.http.delete<HttpResponse<any>>(url).catch(err => throwError(this.error(err)));
	}

	// =============== Examples ===============================================================//
	createExample(workspace_id: string, intent_id: string, body: UserExample): Observable<UserExample> {
		let url = `${this.baseUrl}${environment.api.createExample}`;
		url = url.replace('{workspace_id}', workspace_id.toString()).replace('{intent_id}', intent_id);
		return this.http.post<UserExample>(url, body).catch(err => throwError(this.error(err)));
	}

	updateExample(
		workspace_id: string,
		intent_id: string,
		example_id: string,
		body: UserExample
	): Observable<UserExample> {
		let url = `${this.baseUrl}${environment.api.updateExample}`;
		url = url
			.replace('{workspace_id}', workspace_id.toString())
			.replace('{intent_id}', intent_id)
			.replace('{example_id}', example_id);
		return this.http.put<UserExample>(url, body).catch(err => throwError(this.error(err)));
	}
	getExampleList(workspace_id: string, intent_id: string): Observable<Array<UserExample>> {
		let url = `${this.baseUrl}${environment.api.getExampleList}`;
		url = url.replace('{workspace_id}', workspace_id.toString()).replace('{intent_id}', intent_id);
		return this.http.get<Array<UserExample>>(url).catch(err => throwError(this.error(err)));
	}

	getSingleExample(workspace_id: string, intent_id: string, example_id: string): Observable<UserExample> {
		let url = `${this.baseUrl}${environment.api.getSingleExample}`;
		url = url
			.replace('{workspace_id}', workspace_id.toString())
			.replace('{intent_id}', intent_id)
			.replace('{example_id}', example_id);

		return this.http.get<UserExample>(url).catch(err => throwError(this.error(err)));
	}
	deleteExample(workspace_id: string, intent_id: string, example_id: string): Observable<HttpResponse<any>> {
		let url = `${this.baseUrl}${environment.api.deleteExample}`;
		url = url
			.replace('{workspace_id}', workspace_id.toString())
			.replace('{intent_id}', intent_id)
			.replace('{example_id}', example_id);

		return this.http.delete<HttpResponse<any>>(url).catch(err => throwError(this.error(err)));
	}

	// =============== Dialog Nodes ===============================================================//
	createDialogNode(workspace_id: string, body: DialogNodeModel): Observable<DialogNodeModel> {
		let url = `${this.baseUrl}${environment.api.createDialogNode}`;
		url = url.replace('{workspace_id}', workspace_id.toString());
		return this.http.post<DialogNodeModel>(url, body).catch(err => throwError(this.error(err)));
	}

	updateDialogNode(workspace_id: string, dialog_node_id: string, body: DialogNodeModel): Observable<DialogNodeModel> {
		let url = `${this.baseUrl}${environment.api.updateDialogNode}`;
		url = url.replace('{workspace_id}', workspace_id.toString()).replace('{dialog_node_id}', dialog_node_id);
		return this.http.put<DialogNodeModel>(url, body).catch(err => throwError(this.error(err)));
	}
	getDialogNodeList(workspace_id: string): Observable<Array<DialogNodeModel>> {
		let url = `${this.baseUrl}${environment.api.listDialogNode}`;
		url = url.replace('{workspace_id}', workspace_id.toString());
		return this.http.get<Array<DialogNodeModel>>(url).catch(err => throwError(this.error(err)));
	}

	getSingleDialogNode(workspace_id: string, dialog_node_id: string): Observable<DialogNodeModel> {
		let url = `${this.baseUrl}${environment.api.getSingleDialogNode}`;
		url = url.replace('{workspace_id}', workspace_id.toString()).replace('{dialog_node_id}', dialog_node_id);
		return this.http.get<DialogNodeModel>(url).catch(err => throwError(this.error(err)));
	}
	deleteDialogNode(workspace_id: string, dialog_node_id: string): Observable<HttpResponse<any>> {
		let url = `${this.baseUrl}${environment.api.deleteDialogNode}`;
		url = url.replace('{workspace_id}', workspace_id.toString()).replace('{dialog_node_id}', dialog_node_id);
		return this.http.delete<HttpResponse<any>>(url).catch(err => throwError(this.error(err)));
	}
}
