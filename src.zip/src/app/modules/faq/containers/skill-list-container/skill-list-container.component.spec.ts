import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { SkillListContainerComponent } from './skill-list-container.component';
import { SpinnerComponent } from 'src/app/shared/components/spinner/spinner.component';
import { ListComponent } from 'src/app/shared/components/list/list.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ToastService } from 'src/app/shared/services/toast.service';
import { FaqServiceService } from '../../services/faq-service.service';
import { By } from '@angular/platform-browser';
import { AuthService } from '../../../../core/services/auth.service';

describe('SkillListContainerComponent', () => {
  let component: SkillListContainerComponent;
  let fixture: ComponentFixture<SkillListContainerComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SkillListContainerComponent, SpinnerComponent, ListComponent],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [{ provide: ToastService, useValue: ToastService }, FaqServiceService, AuthService]
    })
      .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(SkillListContainerComponent);
    component = fixture.componentInstance;
    sessionStorage.setItem('userInfo', JSON.stringify({
      "id": 10,
      "first_name": "test+firstlogin",
      "last_name": "New",
      "phone_number": "242.208.1561",
      "email": "test+firstlogin@negobot.co",
      "type": "admin",
      "status": "active",
      "profile_image_url": "http://via.placeholder.com/500x500",
      "twilio_user_id": null,
      "device_token": null,
      "app_status": null,
      "first_signin": true,
      "Staff": {
        "id": 17,
        "organisation_id": 1,
        "user_id": 10,
        "type": "admin",
        "Organisation": {
          "id": 1,
          "name": "Org Name",
          "workspace_id": "1d167ef0-39ef-4fc7-bda0-829d6bcbd5cd",
          "status": "active"
        }
      }
    }));
    let data = JSON.parse(sessionStorage.getItem('userInfo'))
    let workspace_id = data.Staff.Organisation.workspace_id;
    const service: FaqServiceService = TestBed.get(FaqServiceService);
    fixture.detectChanges();
  });
  it('should create skill-list-container component', () => {
    expect(component).toBeTruthy();
  });
  it('able to display list in FAQ', inject([FaqServiceService], (service: FaqServiceService) => {
    expect(service.getWorkspaceList()).toBeTruthy();
  }));
  it('List shows correctly in FAQ ', inject([FaqServiceService], (service: FaqServiceService) => {
    expect(service.getWorkspaceList().subscribe(data => {
      expect(data.length).toBeGreaterThan(0);
    })).toBeTruthy();
  }));
  it('should Able to see Question field in faq Edit view', () => {
    let de = fixture.debugElement.query(By.css('#intent'));
    expect(de).toBeTruthy();
  });

});
