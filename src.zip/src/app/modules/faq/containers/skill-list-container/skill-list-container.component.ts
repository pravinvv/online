import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FaqServiceService } from '../../services/faq-service.service';
import { mergeMap, toArray } from 'rxjs/operators';
import { OrganisationService } from 'src/app/modules/organisation/services/organisation.service';
import { forkJoin, of, from } from 'rxjs';
import { ModalService } from 'src/app/shared/services/modal.service';
import { OrganisationModel } from 'src/app/shared/models/organisation.model';
import { ToastService } from 'src/app/shared/services/toast.service';
import { LoaderService } from 'src/app/shared/services/loader.service';
import { AuthService } from 'src/app/core/services/auth.service';
@Component({
	selector: 'app-skill-list-container',
	templateUrl: './skill-list-container.component.html',
	styleUrls: ['./skill-list-container.component.css'],
})
export class SkillListContainerComponent implements OnInit {
	public setting = {
		columns: {
			intent: {
				title: 'Category',
				filter: true,
				addable: false,
			},
			description: {
				title: 'Description',
				filter: true,
				addable: false,
			},
			example: {
				title: 'Variations',
				filter: true,
				addable: false,
			},
		},
		actions: {
			add: false,
			edit: false,
			delete: false,
			custom: [
				{
					name: 'Edit',
					title: '<i class="ti-pencil text-info m-r-10"> ',
				},
				{
					name: 'Delete',
					title: '<i class="ti-trash text-danger m-r-10"> ',
				},
			],
		},
	};
	private workspace_id: string;
	public source: Array<any> = [];
	constructor(
		private router: Router,
		private faqService: FaqServiceService,
		private auth: AuthService,
		private modalService: ModalService,
		private toast: ToastService,
		private loaderService: LoaderService
	) {}
	ngOnInit() {
		this.getIntentList();
		
	}
	add() {
		this.router.navigate(['/secured/faq/create']);
	}
	edit(id) {
		this.router.navigate(['/secured/faq/edit', id]);
	}
	delete(id) {
		// this.router.navigate(['organisation/edit', id]);
		const modalRef = this.modalService.open({ name: 'confirmation', param: id });
		modalRef.result.then(res => {
			if (res === 'Ok') {
				this.deleteIntent(id);
			}
		});
	}

	private getIntentList() {
		this.loaderService.startLoader('app-faq-list');
		this.workspace_id = this.auth.sessionUserInfo.Staff.Organisation.workspace_id;		
		this.faqService
			.getIntentList(this.workspace_id)
			.pipe(
				mergeMap(m => m),
				mergeMap(intentInfo => {
					return forkJoin(
						of(intentInfo),
						this.faqService.getExampleList(this.workspace_id, intentInfo.intent)
					);
				}),
				mergeMap(d => {
					return of({ ...d[0], example: d[1].length });
				}),
				toArray()
			)

			.subscribe(
				(res: any) => {
					this.loaderService.stopLoader('app-faq-list');
					this.source = res;
				},
				error => {
					this.loaderService.stopLoader('app-faq-list');
				}
			);
	}
	private deleteIntent(id: string) {
		this.faqService.deleteIntent(this.workspace_id, id).subscribe(res => {
			this.toast.showSuccess('Intent deleted successfully');
			const source = JSON.parse(JSON.stringify(this.source));
			const index = source.findIndex(e => e.intent === id);
			source.splice(index, 1);
			this.source = source;
		});
	}
}
