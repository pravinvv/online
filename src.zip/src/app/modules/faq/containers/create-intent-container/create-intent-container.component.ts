import { Component, OnInit } from '@angular/core';
import { OrganisationService } from 'src/app/modules/organisation/services/organisation.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastService } from 'src/app/shared/services/toast.service';
import { IntentModel } from 'src/app/shared/models/intent.model';
import { FaqServiceService } from '../../services/faq-service.service';
import { map, mergeMap, catchError } from 'rxjs/operators';
import { forkJoin, of } from 'rxjs';
import { OrganisationModel } from 'src/app/shared/models/organisation.model';
import { DialogNodeModel } from 'src/app/shared/models/dialog_node.model';
import { UserExample } from 'src/app/shared/models/user_example.model';
import { pipe } from '@angular/core/src/render3';
import { ModalService } from 'src/app/shared/services/modal.service';
import { LoaderService } from 'src/app/shared/services/loader.service';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
	selector: 'app-create-intent-container',
	templateUrl: './create-intent-container.component.html',
	styleUrls: ['./create-intent-container.component.css'],
})
export class CreateIntentContainerComponent implements OnInit {
	public qnaModel: any = { examples: [], dialogNode: {} };
	public workspace_id: string;
	public loaderId = 'app-create-intent';

	constructor(
		private faqService: FaqServiceService,
		private auth: AuthService,
		private router: Router,
		private activatedRoute: ActivatedRoute,
		private toast: ToastService,
		private modalService: ModalService,
		private loaderService: LoaderService
	) {}

	ngOnInit() {
		this.activatedRoute.params.subscribe(params => {
			if (params.id) {
				this.getSingleIntent(params.id);
			} else {
				this.workspace_id = this.auth.sessionUserInfo.Staff.Organisation.workspace_id;
			}
		});
	}
	event(data) {
		switch (data.operation) {
			case 'createIntent':
				this.createIntent(data);
				break;
			case 'updateIntent':
				this.updateIntent(data);
				break;
			case 'createDialogNode':
				this.createDialogNode(data);
				break;
			case 'updateDialogNode':
				this.updateDialogNode(data);
				break;
			case 'createUserExample':
				this.createUserExample(data);
				break;
			case 'deleteUserExample':
				this.deleteUserExample(data);
				break;
			case 'updateUserExample':
				this.updateUserExample(data);
				break;
		}
	}
	private updateIntent(intentModel) {
		// tslint:disable-next-line:prefer-const
		let { intent, description, old_intent } = intentModel;
		const prefix = old_intent.substring(0, old_intent.lastIndexOf('-'));
		intent = intent.replace(prefix, '');
		intent = intent.split(' ').join('_');
		intent = `${prefix}${intent}`;
		this.faqService
			.updateIntent(this.workspace_id, old_intent, { intent, description })
			.pipe(
				map(newIntent => {
					if (this.qnaModel.dialogNode.dialog_node) {
						this.qnaModel.dialogNode.title = newIntent.intent;
						this.qnaModel.dialogNode.conditions = `#${newIntent.intent}`;
						this.qnaModel.dialogNode.old_dialog_node = this.qnaModel.dialogNode.dialog_node;
						this.updateDialogNode(this.qnaModel.dialogNode);
					}
					return newIntent;
				})
			)
			.subscribe(res => {
				this.qnaModel.intent = res.intent;
				this.router.navigate(['/secured/faq/edit', res.intent]);
			});
	}
	private createIntent(intentModel) {
		// tslint:disable-next-line:prefer-const
		let { intent, description } = intentModel;
		intent = intent.split(' ').join('_');
		this.faqService
			.getIntentList(this.workspace_id)
			.pipe(
				mergeMap(intents => {
					if (intents.length) {
						const lastIntent = intents[intents.length - 1].intent;
						const prefixes = lastIntent.substring(0, lastIntent.lastIndexOf('-')).split('-');
						let intentNo = parseInt(prefixes[1], 10);
						intentNo += 1;
						const ntos =
							intentNo.toString().length === 1
								? `00${intentNo}`
								: intentNo.toString().length === 2
								? `0${intentNo}`
								: `00${intentNo}`;
						intent = `${prefixes[0]}-${ntos}-${intent}`;
					} else {
						intent = `QNA-001-${intent}`;
					}
					return this.faqService.createIntent(this.workspace_id, { intent, description });
				}),
				catchError(err => {
					if (err.status === 404) {
						intent = `QNA-001-${intent}`;
						return this.faqService.createIntent(this.workspace_id, { intent, description });
					}
				})
			)
			.subscribe((res: IntentModel) => {
				this.qnaModel.intent = res.intent;
				this.router.navigate(['/secured/faq/edit', res.intent]);
			});
	}
	private updateDialogNode(dialogNodeModel) {
		// tslint:disable-next-line:prefer-const
		let { dialog_node, conditions, description, output, old_dialog_node, title } = dialogNodeModel;
		this.faqService
			.updateDialogNode(this.workspace_id, old_dialog_node, {
				dialog_node,
				conditions,
				description,
				output,
				title,
			})
			.subscribe(res => {
				this.qnaModel.dialogNode.dialog_node = res.dialog_node;
			});
	}
	private createDialogNode(dialogNodeModel) {
		// tslint:disable-next-line:prefer-const
		let { dialog_node, conditions, description, output, title } = dialogNodeModel;

		this.faqService
			.createDialogNode(this.workspace_id, {
				dialog_node,
				conditions,
				output,
				description,
				title,
			})
			.subscribe((res: DialogNodeModel) => {
				this.qnaModel.dialogNode.dialog_node = res.dialog_node;
				this.toast.showSuccess('Answer created.');
			});
	}
	private updateUserExample(exampleModel) {
		// tslint:disable-next-line:prefer-const
		let { text, old_text, intent } = exampleModel;
		this.faqService
			.updateExample(this.workspace_id, intent, old_text, {
				text,
				intent,
			})
			.subscribe(res => {
				this.toast.showSuccess('Question variation updated.');
			});
	}
	private createUserExample(exampleModel) {
		// tslint:disable-next-line:prefer-const
		let { text, intent } = exampleModel;

		this.faqService
			.createExample(this.workspace_id, intent, {
				text,
				intent,
			})
			.subscribe((res: UserExample) => {
				this.qnaModel.examples[this.qnaModel.examples.length] = res;
				this.toast.showSuccess('Question variation created.');
			});
	}
	private deleteUserExample(data) {
		const { intent, text } = data;
		const modalRef = this.modalService.open({ name: 'confirmation', param: text });
		modalRef.result.then(res => {
			if (res === 'Ok') {
				this.faqService.deleteExample(this.workspace_id, intent, text).subscribe(result => {
					this.toast.showSuccess('Question deleted successfully');
					const index = this.qnaModel.examples.findIndex(e => e.text === text);
					this.qnaModel.examples.splice(index, 1);
				});
			}
		});
	}
	private getSingleIntent(intent: string) {
		this.loaderService.startLoader(this.loaderId);
		this.workspace_id = this.auth.sessionUserInfo.Staff.Organisation.workspace_id;
		this.faqService
		.getSingleIntent(this.workspace_id, intent)
		.pipe(
			mergeMap((intentInfo: any) => {
				return forkJoin(of(intentInfo), this.faqService.getDialogNodeList(this.workspace_id));
			}),
			mergeMap((intents: any) => {
				const dialogNode = intents[1].find(n => n.conditions === `#${intents[0].intent}`) || {};
				return of({
					...intents[0],
					dialogNode,
				});
			})
		)
		.subscribe(res => {
			this.qnaModel = res;
			this.loaderService.stopLoader(this.loaderId);
		});
	}
}
