import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateIntentContainerComponent } from './create-intent-container.component';
import { SpinnerComponent } from 'src/app/shared/components/spinner/spinner.component';
import { QnaFormComponent } from '../../components/qna-form/qna-form.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ToastService } from 'src/app/shared/services/toast.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('CreateIntentContainerComponent', () => {
  let component: CreateIntentContainerComponent;
  let fixture: ComponentFixture<CreateIntentContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
        imports:[FormsModule,ReactiveFormsModule,HttpClientTestingModule,RouterTestingModule],
      declarations: [ CreateIntentContainerComponent,SpinnerComponent,QnaFormComponent ],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [{ provide: ToastService, useValue: ToastService }]
    
      
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateIntentContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create Create-intent-Container Component', () => {
    expect(component).toBeTruthy();
  });
});
