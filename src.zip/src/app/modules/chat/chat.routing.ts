import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ChatComponent } from './components/chat/chat.component';

@NgModule({
	imports: [
		RouterModule.forChild([
			{
				path: '',
				component: ChatComponent,
				data: {
					title: 'Chat',
					urls: [{ title: 'Chat', url: 'chat' }, { title: 'Chat' }],
				},
			},
		]),
	],
})
export class ChatRoutingModule {}
