import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatComponent } from './components/chat/chat.component';
import { ChatRoutingModule } from './chat.routing';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
@NgModule({
	declarations: [ChatComponent],
	imports: [
		CommonModule,
		ChatRoutingModule,
		PerfectScrollbarModule,
		NgbModule,
		FormsModule,
		ReactiveFormsModule,
		SharedModule,
		InfiniteScrollModule
	],
})
export class ChatModule {}
