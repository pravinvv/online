import { Injectable } from '@angular/core';
import Client from 'twilio-chat';
import { Message } from 'twilio-chat/lib/message';
import { Channel } from 'twilio-chat/lib/channel';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { BehaviorSubject, Observable, observable } from 'rxjs';
import { delay } from 'rxjs/operators';
@Injectable({
	providedIn: 'root',
})
export class TwillioChatService {
	private messages: Message[] = [];
	private channel: Channel | null = null;
	private client: any = null;
	private messageAddedListener=this.messageAdded.bind(this);
	private getMessage$: BehaviorSubject<Array<Message>> = new BehaviorSubject<Array<Message>>(this.messages);

	constructor(private http: HttpClient) {
		this.initClient();
	}

	get getMessages() {
		return this.getMessage$;
	}

	private registerChannelListeners() {
		if (!this.channel) {
			return;
		}

		this.channel.on('messageAdded', this.messageAddedListener);
	}

	removeChannelListeners() {
		if (!this.channel) {
			return;
		}
		// this.channel.removeAllListeners('messageAdded');
		// this.channel.removeAllListeners('messageAdded');

		return this.channel.removeListener('messageAdded', this.messageAddedListener);
	}
	private messageAdded(msg: Message) {
		this.markMessageAsRead(msg.index);
		this.messages.push(msg);
		this.getMessage$.next(this.messages);
	}

	private getTwillioToken() {
		const url = `${environment.SVC_MESSAGE}${environment.api.getTwillioToken}`;
		return this.http.get(url).toPromise();
	}

	private async initClient() {
		try {
			const tokenResponse: any = await this.getTwillioToken();
			this.client = await Client.create(tokenResponse.token);
		} catch (e) {
		}
	}

	async init(channelUniqueName) {
		try {
			this.channel = await this.client.getChannelByUniqueName(channelUniqueName);
			await this.removeChannelListeners();
			this.registerChannelListeners();
			this.channel.setAllMessagesConsumed();
			this.messages = (await this.channel.getMessages()).items;
			this.getMessage$.next(this.messages);
		} catch (e) {
			console.log(e);
		}
	}
	private async markMessageAsRead(msgIndex?) {
		await this.channel.updateLastConsumedMessageIndex(msgIndex || 0);
	}
	sendMessage(message, attributes?) {
		this.channel.sendMessage(JSON.stringify(message));
	}
	getChatUsers(data?): Observable<Object[]> {
		let url = `${environment.SVC_MESSAGE}${environment.api.getChannels}`;
		if (data) {
			let query;
			for (const i in data) {
				if (query) {
					query = `${query}&${i}=${data[i]}`;
				} else {
					query = `?${i}=${data[i]}`;
				}
			}
			url = `${url}${query}`;
		}
		return this.http.get<Object[]>(url);
	}
	autopilotONOFF(data, channelId) {
		let url = `${environment.SVC_APP}${environment.api.autopilotONOFF}`;
		url = url.replace('{id}', channelId.toString());
		return this.http.put(url, data);
	}
}
