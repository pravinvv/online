import { TestBed } from '@angular/core/testing';

import { TwillioChatService } from './twillio-chat.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ToastService } from '../../../shared/services/toast.service';

describe('TwillioChatService', () => {
  beforeEach(() => TestBed.configureTestingModule({

    imports: [HttpClientTestingModule],
    providers: [{ provide: ToastService, useValue: ToastService }]

  }));

  it('should be created twillio chat swevice', () => {
    const service: TwillioChatService = TestBed.get(TwillioChatService);
    expect(service).toBeTruthy();
  });
});
