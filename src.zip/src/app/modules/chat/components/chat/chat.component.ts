import { Component, OnInit, ViewChild, ElementRef, AfterViewChecked, AfterViewInit, OnDestroy } from '@angular/core';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { TwillioChatService } from '../../services/twillio-chat.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import * as moment from 'moment';
import { LoaderService } from 'src/app/shared/services/loader.service';
import { ToastService } from 'src/app/shared/services/toast.service';
import { interval } from 'rxjs';
import { map, mergeMap } from 'rxjs/operators';

@Component({
	templateUrl: './chat.component.html',
})
export class ChatComponent implements AfterViewChecked, AfterViewInit, OnInit, OnDestroy {
	public config: PerfectScrollbarConfigInterface = {};
	public loaderId = 'app-chat';
	public showSidebar = false;
	public selectedUser: any = {};
	public messages = [];
	public loggedInUser;
	public botName = 'Jenny';
	private intervalSubscriber;
	@ViewChild('chatWindow') private chatWindow: ElementRef;
	public users: Object[] = [];
	public chatForm: FormGroup;
	private filters: any = {};
	constructor(
		private twillioChatService: TwillioChatService,
		private auth: AuthService,
		private formBuilder: FormBuilder,
		private loaderService: LoaderService,
		private toastService: ToastService
	) {
		// this.selectedUser = this.users[1];
	}
	ngOnInit() {
		const { email } = this.auth.sessionUserInfo;
		this.getChatUsers(this.loaderId);

		this.loggedInUser = email;
		this.chatForm = this.formBuilder.group({
			message: ['', [Validators.required]],
		});
		this.twillioChatService.getMessages.subscribe(messages => {
			this.messages = messages;
			this.scrollTo();
		});

		// const source = interval(10000);
		// this.intervalSubscriber = source
		// 	.pipe(
		// 		mergeMap(m => {
		// 			return this.twillioChatService.getChatUsers();
		// 		})
		// 	)
		// 	.subscribe((val: any) => {
		// 		// if (this.users.length !== val.members.length) {
		// 		this.users = val.members;
		// 		// }
		// 	});
	}

	private getChatUsers(loaderId, filters?) {
		this.loaderService.startLoader(loaderId);
		this.twillioChatService.getChatUsers(filters).subscribe(
			(response: any) => {
				if (this.filters.page === response.metaData.page) {
					this.users = response.members;
				} else {
					this.users = this.users.concat(response.members);
				}
				this.filters = response.metaData;

				if (this.users.length) {
					this.onSelect(this.users[0], true);
				}
				this.loaderService.stopLoader(loaderId);
			},
			err => {
				this.loaderService.stopLoader(loaderId);
				this.toastService.showError(err.message, 'Error');
			}
		);
	}
	mobileSidebar() {
		this.showSidebar = !this.showSidebar;
	}
	onSelect(user, isFirst?): void {
		this.selectedUser = user;
		user.unreadCount = 0;
		// this.selectedUser.identity = `User ${user.identity.substring(0, 3)}`;
		// this.twillioChatService.removeChannelListeners();
		if (isFirst) {
			setTimeout(() => {
				this.twillioChatService.init(user.channelSid);
			}, 2000);
		} else {
			this.twillioChatService.init(user.channelSid);
		}
	}
	extractMessage(message) {
		return message ? JSON.parse(message.body).text : '';
	}
	extractBotUnderstable(message) {
		return message ? JSON.parse(message.body).isBotUnderstandable : false;
	}
	extractDate(message) {
		const date =
			message && message.date_created
				? message.date_created
				: message && message.timestamp
				? message.timestamp
				: '';
		return moment(date).fromNow();
	}
	ngAfterViewInit() {}
	ngAfterViewChecked() {
		this.scrollTo();
	}
	ngOnDestroy() {
		this.intervalSubscriber.unsubscribe();
	}
	scrollTo() {
		try {
			this.chatWindow.nativeElement.scrollTop = this.chatWindow.nativeElement.scrollHeight;
		} catch (err) {}
	}
	sendMessage() {
		if (this.chatForm.valid) {
			const { message } = this.chatForm.value;
			const contextMessage = { id: this.loggedInUser, text: message, isBotUnderstandable: false };
			this.twillioChatService.sendMessage(contextMessage);
			this.chatForm.get('message').setValue('');
			this.chatForm.get('message').setValidators(Validators.required);
		}
	}
	autopilotONOFF() {
		let { autopilot, channelSid } = this.selectedUser;
		autopilot = !autopilot;
		channelSid = channelSid.toString();
		this.twillioChatService.autopilotONOFF({ autopilot }, channelSid).subscribe(
			response => {
				this.selectedUser.autopilot = autopilot;
			},
			err => {
				this.toastService.showError(err.message, 'Error');
			}
		);
	}
	scrollPagination(ev) {
		// tslint:disable-next-line:prefer-const
		let { page, page_size, nextPageToken } = this.filters;
		page = (page || 0) + 1;
		const page_token = nextPageToken;
		page_size = page_size;
		const filters: any = { page, page_size };
		if (page_token) {
			filters.page_token = page_token;
		}
		this.getChatUsers('app-chat-user', filters);
	}
}
