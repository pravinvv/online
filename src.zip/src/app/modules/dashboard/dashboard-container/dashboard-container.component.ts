import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-dashboard-container',
	templateUrl: './dashboard-container.component.html',
	styleUrls: ['./dashboard-container.component.css']
})
export class DashboardContainerComponent implements OnInit {
	subtitle: string;
	constructor() {
		this.subtitle = 'This is some text within a card block.';
	}

	ngOnInit() {
	}

}
