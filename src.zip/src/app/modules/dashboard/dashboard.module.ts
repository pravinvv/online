import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DashboardContainerComponent } from './dashboard-container/dashboard-container.component';

const routes: Routes = [
	{
		path: '',
		data: {
			title: 'Dashboard',
			urls: [{ title: 'Dashboard', url: '/dashboard' }, { title: 'Dashboard Page' }],
		},
		component: DashboardContainerComponent,
	},
];
@NgModule({
	declarations: [DashboardContainerComponent],
	imports: [FormsModule, CommonModule, RouterModule.forChild(routes)],
})
export class DashboardModule {}
