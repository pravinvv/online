import { Routes } from '@angular/router';
import { FullComponent } from './layouts/full/full.component';
import { BlankComponent } from './layouts/blank/blank.component';
import { AuthGuard } from './core/guards/auth.guard';
import { AdminGuard } from './core/guards/admin.guard';
import { AccessGuard } from './core/guards/access.guard';
import { SuperadminGuard } from './core/guards/superadmin.guard';
const childRoutes = [
	{
		path: 'dashboard',
		loadChildren: './modules/dashboard/dashboard.module#DashboardModule',
	},
	{
		path: 'organisation',
		loadChildren: './modules/organisation/organisation.module#OrganisationModule',
		// canActivate: [SuperadminGuard],
	},
	{
		path: 'user',
		loadChildren: './modules/user/user.module#UserModule',
		// canActivate: [SuperadminGuard],
	},
	{
		path: 'faq',
		loadChildren: './modules/faq/faq.module#FaqModule',
		// canActivate: [AdminGuard],
	},
	{
		path: 'product',
		loadChildren: './modules/product/product.module#ProductModule',
		// canActivate: [AdminGuard],
	},
	{
		path: 'chat',
		loadChildren: './modules/chat/chat.module#ChatModule',
	},
	{
		path: 'staff',
		loadChildren: './modules/staff/staff.module#StaffModule',
	},
	{ path: '', redirectTo: '/secured/dashboard', pathMatch: 'full' },
];

export const Approutes: Routes = [
	{
		path: 'secured',
		component: FullComponent,
	//	canActivate: [AccessGuard],
		// canActivateChild: [AuthGuard],
		// canDeactivate: [AuthGuard],
		children: childRoutes,
	},
	{
		path: 'secured/organisation/:id',
		component: FullComponent,
		// canActivateChild: [AuthGuard],
		// canDeactivate: [AuthGuard],
		children: childRoutes,
	},
	{
		path: '',
		component: BlankComponent,
		// canActivateChild: [AuthGuard],
		children: [
			{
				path: '',
				loadChildren: './modules/authentication/authentication.module#AuthenticationModule',
			},
		],
	},

	{
		path: '**',
		redirectTo: '/404',
	},
];
