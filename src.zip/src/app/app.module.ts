import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { FullComponent } from './layouts/full/full.component';
import { BlankComponent } from './layouts/blank/blank.component';

import { Approutes } from './app-routing.module';
import { AppComponent } from './app.component';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import { httpInterceptorProviders } from 'src/app/core/interceptors';
import { ToastrModule } from 'ngx-toastr';
import { StaffListContainerComponent } from './modules/staff/containers/staff-list-container/staff-list-container.component';
import { StaffCreateContainerComponent } from './modules/staff/containers/staff-create-container/staff-create-container.component';
import { StaffFormComponent } from './modules/staff/components/staff-form/staff-form.component';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
	suppressScrollX: true,
	wheelSpeed: 2,
	wheelPropagation: true,
	minScrollbarLength: 20,
};

@NgModule({
	declarations: [AppComponent, FullComponent, BlankComponent],
	imports: [
		CommonModule,
		BrowserModule,
		BrowserAnimationsModule,
		FormsModule,
		HttpClientModule,
		NgbModule.forRoot(),
		ToastrModule.forRoot(),
		RouterModule.forRoot(Approutes),
		PerfectScrollbarModule,
		CoreModule,
		SharedModule,
	],
	providers: [
		{
			provide: PERFECT_SCROLLBAR_CONFIG,
			useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG,
		},
	],
	bootstrap: [AppComponent],
})
export class AppModule {}
